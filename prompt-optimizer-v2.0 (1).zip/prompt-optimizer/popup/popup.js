// PromptForge Popup Script

document.addEventListener('DOMContentLoaded', async () => {

  // ─── LOAD STATS ───
  chrome.runtime.sendMessage({ type: 'GET_STATS' }, (res) => {
    if (res?.success && res.data) {
      document.getElementById('stat-optimized').textContent = res.data.optimized || 0;
      document.getElementById('stat-replaced').textContent = res.data.replaced || 0;
      document.getElementById('stat-copied').textContent = res.data.copied || 0;
    }
  });

  // ─── LOAD SETTINGS ───
  chrome.runtime.sendMessage({ type: 'GET_SETTINGS' }, (res) => {
    if (res?.success && res.data) {
      const s = res.data;
      setValue('default-mode', s.mode);
      setValue('default-model', s.model);
      setValue('default-depth', s.depth);
      setValue('min-length', s.minLength);
      setValue('theme', s.theme);
    }
  });

  // ─── CHECK ACTIVE TAB STATUS ───
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const statusDot = document.querySelector('.status-dot');
  const statusText = document.getElementById('status-text');

  if (tab?.id) {
    chrome.tabs.sendMessage(tab.id, { type: 'PING' }, (res) => {
      if (chrome.runtime.lastError || !res?.alive) {
        statusDot.className = 'status-dot pf-inactive';
        statusText.textContent = 'Not active on this page';
      } else {
        statusDot.className = 'status-dot pf-active';
        statusText.textContent = `Active on ${res.platform || 'this page'}`;
      }
    });
  }

  // ─── SAVE BUTTON ───
  document.getElementById('save-btn').addEventListener('click', () => {
    const settings = {
      mode: getValue('default-mode'),
      model: getValue('default-model'),
      depth: getValue('default-depth'),
      minLength: parseInt(getValue('min-length')) || 50,
      theme: getValue('theme')
    };

    chrome.runtime.sendMessage({ type: 'SAVE_SETTINGS', payload: settings }, (res) => {
      const feedback = document.getElementById('save-feedback');
      if (res?.success) {
        feedback.textContent = '✓ Settings saved successfully';
        feedback.style.color = '#00D4AA';
      } else {
        feedback.textContent = '⚠ Failed to save settings';
        feedback.style.color = '#FF5C7A';
      }
      setTimeout(() => { feedback.textContent = ''; }, 3000);
    });
  });

  // ─── HELPERS ───
  function getValue(id) {
    return document.getElementById(id)?.value || '';
  }

  function setValue(id, val) {
    const el = document.getElementById(id);
    if (el && val !== undefined && val !== null) el.value = val;
  }
});
