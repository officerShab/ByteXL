// PromptForge Widget v1.1
// Fixes: ghost area, FAB visibility, re-optimize, score animation, re-inject self if removed

window.PromptForge = window.PromptForge || {};

window.PromptForge.Widget = (function () {

  let _container   = null;
  let _panel       = null;
  let _fab         = null;
  let _isPanelOpen = false;
  let _isSettingsOpen = false;
  let _lastResult  = null;
  let _lastRawInput = '';   // tracks input at time of last optimization (for re-optimize)
  let _settings    = {};
  let _platform    = null;
  let _isDragging  = false;
  let _dragOffset  = { x: 0, y: 0 };
  let _scoreAnimRunning = false;

  // ─── BUILD HTML ──────────────────────────────────────────────────────────

  function buildHTML(platform) {
    return `
<div id="pf-panel" class="pf-hidden" role="dialog" aria-label="PromptForge optimizer">
  <div id="pf-header">
    <div id="pf-header-title">
      <div id="pf-logo-mark">⚡</div>
      <span>PromptForge</span>
      <span id="pf-platform-badge">${platform.adapter.name}</span>
    </div>
    <div id="pf-header-actions">
      <button class="pf-icon-btn" id="pf-settings-toggle" title="Settings">
        <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M12 1v4M12 19v4M4.22 4.22l2.83 2.83M16.95 16.95l2.83 2.83M1 12h4M19 12h4M4.22 19.78l2.83-2.83M16.95 7.05l2.83-2.83"/></svg>
      </button>
      <button class="pf-icon-btn" id="pf-close-btn" title="Close">
        <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </div>
  </div>

  <div id="pf-body">
    <div id="pf-mode-row" role="group" aria-label="Optimization mode">
      <button class="pf-mode-btn" data-mode="simple">Simple</button>
      <button class="pf-mode-btn pf-active" data-mode="advanced">Advanced</button>
      <button class="pf-mode-btn" data-mode="basic">Basic</button>
      <button class="pf-mode-btn" data-mode="coding">Code</button>
      <button class="pf-mode-btn" data-mode="research">Research</button>
      <button class="pf-mode-btn" data-mode="exam">Exam</button>
      <button class="pf-mode-btn" data-mode="creative">Creative</button>
    </div>

    <button id="pf-optimize-btn">
      <span class="pf-btn-text">
        <svg width="14" height="14" viewBox="0 0 24 24" stroke="#fff" fill="none" stroke-width="2.5" stroke-linecap="round" style="display:inline;vertical-align:middle;margin-right:5px"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
        Optimize Prompt
      </span>
      <div class="pf-spinner"></div>
    </button>

    <div id="pf-score-stages" style="display:none">
      <div class="pf-stage-row">
        <div class="pf-stage-item" id="pf-stage-1"><span class="pf-stage-dot"></span><span class="pf-stage-text">Evaluating...</span></div>
        <div class="pf-stage-item" id="pf-stage-2"><span class="pf-stage-dot"></span><span class="pf-stage-text">Refining...</span></div>
        <div class="pf-stage-item" id="pf-stage-3"><span class="pf-stage-dot"></span><span class="pf-stage-text">Enhancing...</span></div>
        <div class="pf-stage-item" id="pf-stage-4"><span class="pf-stage-dot"></span><span class="pf-stage-text">Perfecting...</span></div>
      </div>
    </div>

    <div id="pf-preview-section">
      <div id="pf-preview-label">
        Optimized Prompt
        <span id="pf-score-badge">✦ 10/10</span>
      </div>
      <div id="pf-preview-text" tabindex="0"></div>
      <div id="pf-info-row"></div>
      <div id="pf-actions-row">
        <button class="pf-action-btn pf-replace-btn" id="pf-replace-btn">
          <svg viewBox="0 0 24 24"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 .49-3"/></svg>
          Replace
        </button>
        <button class="pf-action-btn pf-copy-btn" id="pf-copy-btn">
          <svg viewBox="0 0 24 24"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
          Copy
        </button>
        <button class="pf-action-btn pf-fresh-btn" id="pf-fresh-btn" title="Clear and start over">
          <svg viewBox="0 0 24 24"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 .49-3"/></svg>
          New
        </button>
      </div>
    </div>

    <div id="pf-status-bar"></div>

    <div id="pf-settings-panel">
      <div class="pf-setting-row">
        <span class="pf-setting-label">AI Model</span>
        <select class="pf-setting-control" id="pf-model-select">
          <option value="auto">Auto-detect</option>
          <option value="chatgpt">ChatGPT</option>
          <option value="claude">Claude</option>
          <option value="gemini">Gemini</option>
        </select>
      </div>
      <div class="pf-setting-row">
        <span class="pf-setting-label">Depth Level</span>
        <select class="pf-setting-control" id="pf-depth-select">
          <option value="beginner">Beginner</option>
          <option value="intermediate" selected>Intermediate</option>
          <option value="expert">Expert</option>
        </select>
      </div>
      <div class="pf-setting-row">
        <span class="pf-setting-label">Min Words</span>
        <input type="number" class="pf-setting-control" id="pf-minlength-input" min="0" max="500" value="200" style="width:70px;">
      </div>
      <div class="pf-setting-row">
        <span class="pf-setting-label">Theme</span>
        <select class="pf-setting-control" id="pf-theme-select">
          <option value="dark" selected>Dark</option>
          <option value="light">Light</option>
        </select>
      </div>
    </div>
  </div>
</div>

<button id="pf-fab" title="PromptForge — Optimize Prompt" aria-label="Open PromptForge">
  <svg viewBox="0 0 24 24"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
</button>
`;
  }

  // ─── SCORE ANIMATION ─────────────────────────────────────────────────────

  async function runScoreAnimation(rawInput) {
    _scoreAnimRunning = true;
    const stagesEl = _container.querySelector('#pf-score-stages');
    const badge = _container.querySelector('#pf-score-badge');
    const stageItems = [
      _container.querySelector('#pf-stage-1'),
      _container.querySelector('#pf-stage-2'),
      _container.querySelector('#pf-stage-3'),
      _container.querySelector('#pf-stage-4')
    ];

    const stages = window.PromptForge.Engine.getScoreStages(rawInput);
    stagesEl.style.display = 'block';

    // Reset all stages
    stageItems.forEach(el => {
      if (el) { el.classList.remove('pf-stage-active', 'pf-stage-done'); }
    });
    if (badge) { badge.textContent = '...'; badge.className = 'pf-badge-loading'; }

    for (let i = 0; i < stages.length && i < 4; i++) {
      await new Promise(r => setTimeout(r, stages[i].delay));
      if (!_scoreAnimRunning) break;

      if (stageItems[i]) {
        stageItems[i].classList.add('pf-stage-active');
        stageItems[i].querySelector('.pf-stage-text').textContent = stages[i].label;
      }
      if (badge) badge.textContent = stages[i].label.split(':')[1]?.trim() || stages[i].label;

      // Mark previous as done
      if (i > 0 && stageItems[i-1]) {
        stageItems[i-1].classList.remove('pf-stage-active');
        stageItems[i-1].classList.add('pf-stage-done');
      }
    }

    // Final state
    await new Promise(r => setTimeout(r, stages[stages.length - 1]?.delay || 250));
    if (badge) {
      badge.textContent = '✦ 10/10';
      badge.className = 'pf-badge-perfect';
    }
    stageItems.forEach(el => {
      if (el) { el.classList.remove('pf-stage-active'); el.classList.add('pf-stage-done'); }
    });

    setTimeout(() => {
      if (stagesEl) stagesEl.style.display = 'none';
    }, 1200);

    _scoreAnimRunning = false;
  }

  // ─── DRAG ─────────────────────────────────────────────────────────────────

  function initDrag() {
    const header = _container.querySelector('#pf-header');
    if (!header) return;

    header.addEventListener('mousedown', (e) => {
      if (e.target.closest('.pf-icon-btn')) return;
      _isDragging = true;
      const rect = _container.getBoundingClientRect();
      _dragOffset.x = e.clientX - rect.left;
      _dragOffset.y = e.clientY - rect.top;
      _container.style.transition = 'none';
      document.body.style.userSelect = 'none';
      e.preventDefault();
    });

    document.addEventListener('mousemove', (e) => {
      if (!_isDragging) return;
      const maxX = window.innerWidth - (_container.offsetWidth || 360) - 8;
      const maxY = window.innerHeight - (_container.offsetHeight || 100) - 8;
      const x = Math.max(8, Math.min(e.clientX - _dragOffset.x, maxX));
      const y = Math.max(8, Math.min(e.clientY - _dragOffset.y, maxY));
      _container.style.right = 'auto';
      _container.style.bottom = 'auto';
      _container.style.left = x + 'px';
      _container.style.top  = y + 'px';
    });

    document.addEventListener('mouseup', () => {
      if (!_isDragging) return;
      _isDragging = false;
      _container.style.transition = '';
      document.body.style.userSelect = '';
      try {
        const rect = _container.getBoundingClientRect();
        if (window.PromptForge.Storage) window.PromptForge.Storage.saveWidgetPosition(rect.left, rect.top);
      } catch(e) {}
    });

    // Touch
    header.addEventListener('touchstart', (e) => {
      if (e.target.closest('.pf-icon-btn')) return;
      const t = e.touches[0];
      _isDragging = true;
      const rect = _container.getBoundingClientRect();
      _dragOffset.x = t.clientX - rect.left;
      _dragOffset.y = t.clientY - rect.top;
      e.preventDefault();
    }, { passive: false });

    document.addEventListener('touchmove', (e) => {
      if (!_isDragging) return;
      const t = e.touches[0];
      _container.style.right = 'auto';
      _container.style.bottom = 'auto';
      _container.style.left = Math.max(8, t.clientX - _dragOffset.x) + 'px';
      _container.style.top  = Math.max(8, t.clientY - _dragOffset.y) + 'px';
      e.preventDefault();
    }, { passive: false });

    document.addEventListener('touchend', () => { _isDragging = false; });
  }

  // ─── PANEL TOGGLE ─────────────────────────────────────────────────────────

  function togglePanel() {
    _isPanelOpen = !_isPanelOpen;
    if (_isPanelOpen) {
      _panel.classList.remove('pf-hidden');
      _panel.classList.add('pf-visible');
    } else {
      _panel.classList.remove('pf-visible');
      _panel.classList.add('pf-hidden');
    }
  }

  function closePanel() {
    _isPanelOpen = false;
    _panel.classList.remove('pf-visible');
    _panel.classList.add('pf-hidden');
  }

  // ─── SETTINGS ─────────────────────────────────────────────────────────────

  function toggleSettings() {
    _isSettingsOpen = !_isSettingsOpen;
    const sp = _container.querySelector('#pf-settings-panel');
    if (sp) sp.classList.toggle('pf-visible', _isSettingsOpen);
  }

  // ─── STATUS BAR ───────────────────────────────────────────────────────────

  function showStatus(msg, type, duration) {
    duration = duration !== undefined ? duration : 3000;
    const bar = _container.querySelector('#pf-status-bar');
    if (!bar) return;
    bar.textContent = msg;
    bar.className = 'pf-visible pf-' + (type || 'info');
    if (duration > 0) {
      setTimeout(() => { bar.className = ''; }, duration);
    }
  }

  // ─── OPTIMIZE ─────────────────────────────────────────────────────────────

  async function handleOptimize() {
    const btn = _container.querySelector('#pf-optimize-btn');
    const pf = window.PromptForge;

    // Determine what to optimize:
    // If we have a previous result AND the raw input hasn't changed → re-optimize
    const currentRaw = (pf.DOMDetector.readInput() || '').trim();
    let inputToOptimize;
    let isReOptimize = false;

    if (_lastResult && _lastResult.optimized && currentRaw === _lastRawInput && currentRaw !== '') {
      // Re-optimize the previously generated prompt
      inputToOptimize = _lastResult.optimized;
      isReOptimize = true;
    } else {
      // Fresh optimization from textarea
      inputToOptimize = currentRaw;
      _lastRawInput = currentRaw;
    }

    if (!inputToOptimize || inputToOptimize.trim().length === 0) {
      showStatus('⚠ Please type a prompt first.', 'error', 3500);
      return;
    }

    // Loading state
    btn.classList.add('pf-loading');
    showStatus(isReOptimize ? '🔄 Re-optimizing to perfection...' : '⚡ Analyzing and optimizing...', 'info', 0);

    // Kick off score animation (runs concurrently)
    const animPromise = runScoreAnimation(isReOptimize ? currentRaw : inputToOptimize);

    // Run engine (synchronous but we yield to let animation frame start)
    await new Promise(r => setTimeout(r, 30));

    let result;
    try {
      const currentMode = (_container.querySelector('.pf-mode-btn.pf-active') || {}).dataset?.mode || 'advanced';
      const settings    = await getCurrentSettings();

      result = pf.Engine.optimize(inputToOptimize, {
        mode:      currentMode,
        model:     settings.model,
        minLength: settings.minLength,
        depth:     settings.depth
      });

      if (result.error) {
        showStatus('⚠ ' + result.error, 'error', 4000);
        _scoreAnimRunning = false;
        return;
      }

      _lastResult = result;

    } catch (e) {
      console.error('[PromptForge] Optimization error:', e);
      showStatus('⚠ Optimization failed. Please try again.', 'error', 4000);
      _scoreAnimRunning = false;
      return;
    } finally {
      // Wait for animation to finish before showing result
      await animPromise;
      btn.classList.remove('pf-loading');
    }

    renderPreview(result, isReOptimize);
    showStatus(isReOptimize ? '✦ Further refined to 10/10' : '✓ Optimized to 10/10', 'success', 3000);

    try {
      if (chrome && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({ type: 'INCREMENT_STAT', payload: { key: 'optimized' } });
      }
    } catch(e) {}
  }

  // ─── RENDER PREVIEW ───────────────────────────────────────────────────────

  function renderPreview(result, isReOptimize) {
    const section     = _container.querySelector('#pf-preview-section');
    const previewText = _container.querySelector('#pf-preview-text');
    const infoRow     = _container.querySelector('#pf-info-row');

    previewText.textContent = result.optimized;

    const mult = result.multiplier || '8';
    const examTag = result.examType ? `<span class="pf-info-tag pf-tag-exam">🎯 ${result.examType}</span>` : '';
    const reoptTag = isReOptimize ? '<span class="pf-info-tag pf-tag-reopt">🔁 Refined</span>' : '';
    const refineTag = result.isRefinement ? '<span class="pf-info-tag pf-tag-reopt">✨ Elevated</span>' : '';
    infoRow.innerHTML = [
      `<span class="pf-info-tag">📌 ${cap(result.intent || 'general')}</span>`,
      `<span class="pf-info-tag">🌐 ${cap(result.domain || 'general')}</span>`,
      `<span class="pf-info-tag">📝 ${result.wordCount}w</span>`,
      `<span class="pf-info-tag">🚀 ${mult}x</span>`,
      examTag, reoptTag, refineTag
    ].join('');

    section.classList.add('pf-visible');
  }

  // ─── REPLACE ─────────────────────────────────────────────────────────────

  async function handleReplace() {
    if (!_lastResult) return;
    const success = window.PromptForge.DOMDetector.writeInput(_lastResult.optimized);
    if (success) {
      const btn = _container.querySelector('#pf-replace-btn');
      btn.classList.add('pf-success');
      btn.innerHTML = `<svg viewBox="0 0 24 24" style="width:12px;height:12px;stroke:currentColor;fill:none;stroke-width:2"><polyline points="20 6 9 17 4 12"/></svg> Replaced!`;
      showStatus('✓ Optimized prompt replaced in input field', 'success', 3000);
      setTimeout(() => {
        btn.classList.remove('pf-success');
        btn.innerHTML = `<svg viewBox="0 0 24 24"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 .49-3"/></svg> Replace`;
      }, 2500);
      try {
        if (chrome && chrome.runtime) chrome.runtime.sendMessage({ type: 'INCREMENT_STAT', payload: { key: 'replaced' } });
      } catch(e) {}
    } else {
      showStatus('⚠ Click in the chat input field first, then Replace.', 'error', 4000);
    }
  }

  // ─── COPY ─────────────────────────────────────────────────────────────────

  async function handleCopy() {
    if (!_lastResult) return;
    try {
      await navigator.clipboard.writeText(_lastResult.optimized);
    } catch (e) {
      // Fallback
      const ta = document.createElement('textarea');
      ta.value = _lastResult.optimized;
      ta.style.cssText = 'position:fixed;opacity:0;top:0;left:0';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
    }
    const btn = _container.querySelector('#pf-copy-btn');
    btn.classList.add('pf-success');
    btn.innerHTML = `<svg viewBox="0 0 24 24" style="width:12px;height:12px;stroke:currentColor;fill:none;stroke-width:2"><polyline points="20 6 9 17 4 12"/></svg> Copied!`;
    showStatus('✓ Copied to clipboard', 'success', 2500);
    setTimeout(() => {
      btn.classList.remove('pf-success');
      btn.innerHTML = `<svg viewBox="0 0 24 24"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg> Copy`;
    }, 2500);
    try {
      if (chrome && chrome.runtime) chrome.runtime.sendMessage({ type: 'INCREMENT_STAT', payload: { key: 'copied' } });
    } catch(e) {}
  }

  // ─── FRESH START ──────────────────────────────────────────────────────────

  function handleFresh() {
    _lastResult   = null;
    _lastRawInput = '';
    const section = _container.querySelector('#pf-preview-section');
    if (section) section.classList.remove('pf-visible');
    const badge = _container.querySelector('#pf-score-badge');
    if (badge) { badge.textContent = '✦ 10/10'; badge.className = ''; }
    showStatus('🗑 Cleared — ready for new prompt', 'info', 2000);
  }

  // ─── SETTINGS HELPERS ─────────────────────────────────────────────────────

  async function getCurrentSettings() {
    return {
      model:     (_container.querySelector('#pf-model-select')     || {}).value || 'auto',
      depth:     (_container.querySelector('#pf-depth-select')     || {}).value || 'intermediate',
      minLength: parseInt((_container.querySelector('#pf-minlength-input') || {}).value || '200')
    };
  }

  function applyTheme(theme) {
    _container.classList.toggle('pf-light', theme === 'light');
  }

  async function saveSettingsFromUI() {
    const settings = await getCurrentSettings();
    const theme = (_container.querySelector('#pf-theme-select') || {}).value || 'dark';
    settings.theme = theme;
    applyTheme(theme);
    try {
      if (chrome && chrome.runtime) {
        chrome.runtime.sendMessage({ type: 'SAVE_SETTINGS', payload: settings });
      } else if (window.PromptForge.Storage) {
        window.PromptForge.Storage.set('settings', settings);
      }
    } catch(e) {}
  }

  function cap(str) { return str ? str.charAt(0).toUpperCase() + str.slice(1) : ''; }

  // ─── CONTAINER GUARD ─────────────────────────────────────────────────────
  // Re-inject our widget if a page MutationObserver removes our container

  function startContainerGuard() {
    const observer = new MutationObserver(() => {
      if (_container && !document.body.contains(_container)) {
        console.warn('[PromptForge] Container removed from DOM — re-injecting...');
        document.body.appendChild(_container);
      }
    });
    observer.observe(document.body, { childList: true, subtree: false });
  }

  // ─── PUBLIC INIT ─────────────────────────────────────────────────────────

  return {
    async init(platform) {
      _platform = platform;

      // Prevent duplicate initialization
      if (document.getElementById('pf-widget-container')) {
        console.warn('[PromptForge] Widget already in DOM, skipping re-init.');
        return;
      }

      _container = document.createElement('div');
      _container.id = 'pf-widget-container';
      _container.innerHTML = buildHTML(platform);
      document.body.appendChild(_container);

      _panel = _container.querySelector('#pf-panel');
      _fab   = _container.querySelector('#pf-fab');

      // Load settings
      let saved = {};
      try {
        if (chrome && chrome.runtime && chrome.runtime.sendMessage) {
          saved = await new Promise(resolve => {
            chrome.runtime.sendMessage({ type: 'GET_SETTINGS' }, res => resolve(res && res.data || {}));
          });
        }
      } catch (e) {}

      // Restore position
      const pos = saved.widgetPosition;
      if (pos && pos.x && pos.y) {
        _container.style.right  = 'auto';
        _container.style.bottom = 'auto';
        _container.style.left   = pos.x + 'px';
        _container.style.top    = pos.y + 'px';
      }

      // Apply saved settings
      if (saved.model)    { const el = _container.querySelector('#pf-model-select');    if (el) el.value = saved.model; }
      if (saved.depth)    { const el = _container.querySelector('#pf-depth-select');    if (el) el.value = saved.depth; }
      if (saved.minLength){ const el = _container.querySelector('#pf-minlength-input'); if (el) el.value = saved.minLength; }
      if (saved.theme)    { const el = _container.querySelector('#pf-theme-select');    if (el) el.value = saved.theme; applyTheme(saved.theme); }
      if (saved.mode) {
        _container.querySelectorAll('.pf-mode-btn').forEach(btn => {
          btn.classList.toggle('pf-active', btn.dataset.mode === saved.mode);
        });
      }

      // ── Event Listeners ──

      _fab.addEventListener('click', togglePanel);
      _container.querySelector('#pf-close-btn').addEventListener('click', closePanel);
      _container.querySelector('#pf-settings-toggle').addEventListener('click', (e) => {
        e.stopPropagation(); toggleSettings();
      });

      _container.querySelectorAll('.pf-mode-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          _container.querySelectorAll('.pf-mode-btn').forEach(b => b.classList.remove('pf-active'));
          btn.classList.add('pf-active');
          // Reset on mode change so next optimize uses fresh input
          _lastResult   = null;
          _lastRawInput = '';
          const ps = _container.querySelector('#pf-preview-section');
          if (ps) ps.classList.remove('pf-visible');
        });
      });

      _container.querySelector('#pf-optimize-btn').addEventListener('click', handleOptimize);
      _container.querySelector('#pf-replace-btn').addEventListener('click', handleReplace);
      _container.querySelector('#pf-copy-btn').addEventListener('click', handleCopy);
      _container.querySelector('#pf-fresh-btn').addEventListener('click', handleFresh);

      ['#pf-model-select','#pf-depth-select','#pf-minlength-input','#pf-theme-select'].forEach(sel => {
        const el = _container.querySelector(sel);
        if (el) el.addEventListener('change', saveSettingsFromUI);
      });

      initDrag();
      startContainerGuard();

      console.log('[PromptForge] Widget v1.1 initialized on', platform.adapter.name);
    },

    destroy() {
      if (_container && _container.parentNode) _container.parentNode.removeChild(_container);
      _container = null;
    },

    getContainer() { return _container; }
  };

})();
