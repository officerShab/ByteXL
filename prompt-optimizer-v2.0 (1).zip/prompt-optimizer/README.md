# PromptForge — AI Prompt Optimizer Chrome Extension

## Overview

PromptForge is a production-grade Chrome extension that transforms raw, vague AI prompts into structured, expert-level instructions in real-time. It operates as a **Cognitive Prompt Compiler** — converting natural human intent into model-optimized, context-aware prompts using a multi-layer transformation pipeline.

---

## Supported Platforms

| Platform | URL | Status |
|---|---|---|
| ChatGPT | chatgpt.com / chat.openai.com | ✅ Full support |
| Claude | claude.ai | ✅ Full support |
| Gemini | gemini.google.com | ✅ Full support |
| Perplexity | perplexity.ai | ✅ Full support |
| Poe | poe.com | ✅ Full support |
| Mistral | chat.mistral.ai | ✅ Full support |

---

## Installation (Developer Mode)

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable **Developer mode** (toggle, top-right)
3. Click **Load unpacked**
4. Select the `prompt-optimizer` folder
5. The extension icon (⚡) appears in your toolbar

No build step required. Pure Manifest V3 extension.

---

## File Structure

```
prompt-optimizer/
├── manifest.json                  # MV3 extension manifest
├── background/
│   └── service-worker.js          # Message router, settings sync, API bridge
├── content/
│   ├── content.js                 # Main orchestrator (entry point)
│   ├── dom-detector.js            # Heuristic input detection + MutationObserver
│   └── platform-adapters.js      # Platform-specific selectors + DOM injection
├── engine/
│   └── prompt-engine.js          # Core transformation pipeline
├── widget/
│   ├── widget.js                  # Draggable UI controller
│   └── widget.css                 # Glassmorphism dark UI
├── utils/
│   └── storage.js                 # chrome.storage wrapper
├── popup/
│   ├── popup.html                 # Extension settings popup
│   ├── popup.css                  # Popup styles
│   └── popup.js                   # Settings load/save, usage stats
└── icons/
    ├── icon16.png
    ├── icon32.png
    ├── icon48.png
    └── icon128.png
```

---

## Optimization Modes

| Mode | Description | Best For |
|---|---|---|
| **Advanced** | Full multi-layer transformation: Role, Objective, Context, Task Breakdown, Constraints, Format | Most use cases |
| **Basic** | Lightweight enhancement — adds structure and role definition | Quick prompts |
| **Code** | Engineering brief with language, requirements, edge cases, testing | Programming tasks |
| **Research** | Rigorous research query with methodology and evidence requirements | Academic/analytical work |
| **Exam** | Competitive exam preparation structure (UPSC, SSC, GATE, etc.) | Indian competitive exams |

---

## How the Prompt Engine Works

The engine executes a 5-layer pipeline:

1. **Intent Detection** — Classifies the prompt type (code, explain, research, analyze, create, etc.) using keyword pattern matching across 9 categories.
2. **Domain Detection** — Identifies the knowledge domain (technology, medicine, law, finance, science, education) to apply domain-specific constraints.
3. **Context Enrichment** — Infers audience level, use case, and implicit assumptions from the raw input.
4. **Structural Rebuild** — Constructs the full prompt with: Role → Objective → Context → Task Breakdown → Constraints → Output Format → Depth Control → Reasoning Style → Quality Requirements.
5. **Model-Specific Adaptation** — Applies model-aware suffixes and style adjustments for ChatGPT (structured + step-by-step), Claude (reasoning-heavy), and Gemini (concise + factual).

---

## Configuration Options

Accessible via the extension popup (click ⚡ in toolbar):

| Setting | Options | Default |
|---|---|---|
| Default Mode | Advanced / Basic / Code / Research / Exam | Advanced |
| Target AI Model | Auto-detect / ChatGPT / Claude / Gemini | Auto-detect |
| Expertise Depth | Beginner / Intermediate / Expert | Intermediate |
| Min Prompt Words | 0–300 | 50 |
| Widget Theme | Dark / Light | Dark |

---

## Widget Usage

1. Navigate to any supported AI platform
2. Click the ⚡ FAB button (bottom-right corner)
3. Select your optimization mode
4. Click **Optimize Prompt** — the engine transforms your current input
5. Preview the result in the panel
6. Click **Replace** to insert it into the input field, or **Copy** to copy to clipboard

The widget is fully draggable — position it anywhere, and it remembers your preference.

---

## Security & Privacy

- **No external API calls** — all prompt processing runs locally in-browser using pure JavaScript
- **No data collection** — prompts are never stored or transmitted outside the browser
- **Minimal permissions** — only requests `storage`, `clipboardWrite`, and `scripting`
- **Host permissions** scoped to specific AI platform domains only

---

## Testing Strategy

**DOM Detection Testing**
```
1. Load each supported platform
2. Open DevTools → Console
3. Type: window.PromptForge.DOMDetector.readInput()
4. Should return current textarea value
```

**Injection Testing**
```
1. Type: window.PromptForge.DOMDetector.writeInput("Test prompt")
2. Verify it appears in the input field and send button activates
```

**Engine Unit Testing**
```
window.PromptForge.Engine.optimize("explain machine learning", { mode: "advanced", model: "claude" })
// Should return fully structured prompt with all 9 sections
```

---

## Scalability & Roadmap

**Near-term additions**
- Optional OpenAI/Anthropic API key for AI-powered enhancement (backend in service worker is already stubbed)
- Prompt history panel (last 10 optimized prompts, stored locally)
- Custom mode builder — user-defined prompt templates

**Architecture for new platforms**
Add an entry to `platform-adapters.js` under `PromptForge.platformAdapters` and add the domain to `manifest.json` host_permissions. No other files require changes.

**Performance baseline**
- Cold optimization (local engine): ~10–50ms
- DOM detection retry loop: max 10 seconds (20 × 500ms)
- Widget CSS transitions: 220ms
- No synchronous blocking operations in content scripts

---

## Troubleshooting

| Issue | Solution |
|---|---|
| Widget doesn't appear | Refresh the page. Check extension is enabled at chrome://extensions |
| Replace button does nothing | Click inside the chat input first, then use Replace |
| Optimization fails silently | Open DevTools console, look for `[PromptForge]` log entries |
| Widget disappeared after drag | Reload extension: chrome://extensions → PromptForge → reload icon |
