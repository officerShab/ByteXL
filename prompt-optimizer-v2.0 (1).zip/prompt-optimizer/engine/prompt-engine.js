// PromptForge Prompt Engine v2.0
// ─── COMPLETE CONTEXT-AWARE REWRITE ────────────────────────────────────────
// Every section of every mode is dynamically generated from input context.
// The engine deeply understands WHO is asking, WHAT they want, and HOW they
// want it — then builds a prompt where every section is specific to that input.

window.PromptForge = window.PromptForge || {};

window.PromptForge.Engine = (function () {

  // ══════════════════════════════════════════════════════════════════════════
  // CONTEXT EXTRACTOR
  // ══════════════════════════════════════════════════════════════════════════

  function extractPersonType(t) {
    if (/\b(ssc|upsc|gate|jee|neet|cat|ias|ips|aspirant|preparing for)\b/i.test(t)) return 'exam_aspirant';
    if (/\b(student|studying|class \d+|school|college|university|b\.?tech|m\.?tech|bsc|msc)\b/i.test(t)) return 'student';
    if (/\b(developer|programmer|software engineer|coder|devops|full[- ]?stack|backend|frontend|architect)\b/i.test(t)) return 'developer';
    if (/\b(researcher|analyst|scientist|phd|professor|academic|thesis|dissertation)\b/i.test(t)) return 'researcher';
    if (/\b(manager|ceo|cto|founder|startup|entrepreneur|business owner|product manager)\b/i.test(t)) return 'business';
    if (/\b(designer|ux|ui|graphic|creative|artist|illustrator)\b/i.test(t)) return 'designer';
    if (/\b(writer|blogger|content creator|journalist|author|copywriter)\b/i.test(t)) return 'writer';
    if (/\b(doctor|medical|patient|health|nurse|clinical|hospital)\b/i.test(t)) return 'medical';
    if (/\b(teacher|tutor|educator|instructor|coach|mentor)\b/i.test(t)) return 'educator';
    if (/\bi am|i'm|as a\b/i.test(t)) return 'self_identified';
    return 'general';
  }

  function extractExamType(t) {
    if (/\bssc\b|\bcgl\b|\bchsl\b|\bgd constable\b|\bmts\b/i.test(t)) return 'SSC';
    if (/\bupsc\b|\bias\b|\bips\b|\bcivil services\b|\bprelims\b|\bmains\b/i.test(t)) return 'UPSC';
    if (/\bgate\b/i.test(t)) return 'GATE';
    if (/\bjee\b|\bjee main\b|\bjee advanced\b/i.test(t)) return 'JEE';
    if (/\bneet\b|\bmbbs entrance\b/i.test(t)) return 'NEET';
    if (/\bcat\b|\biim\b|\bmba entrance\b/i.test(t)) return 'CAT';
    if (/\bibps\b|\bsbi po\b|\bbank po\b|\bbank clerk\b|\bbanking exam\b/i.test(t)) return 'Banking';
    if (/\bnda\b|\bcds\b|\bafcat\b|\bdefence exam\b/i.test(t)) return 'Defence';
    if (/\bclat\b|\blaw entrance\b/i.test(t)) return 'CLAT';
    if (/\bboard exam\b|\bclass 10\b|\bclass 12\b|\bcbse\b|\bicse\b/i.test(t)) return 'Board';
    return null;
  }

  function extractAction(t) {
    if (/\b(find|search|recommend|suggest|list|give me|tell me|show me|who is|which is|best)\b.{0,20}\b(teacher|course|platform|resource|book|tool|app|service|doctor|lawyer|expert|professional)\b/i.test(t) || /\b(teacher|coach|tutor|instructor|platform|course|batch)\b/i.test(t)) return 'recommend';
    if (/\b(debug|fix|error|bug|not working|broken|issue|problem|crash|exception|failing)\b/i.test(t)) return 'debug';
    if (/\b(build|create|implement|develop|code|write code|program|make a|build a|create a)\b/i.test(t)) return 'code';
    if (/\b(write|draft|compose|create|generate)[^.]{0,30}\b(essay|article|blog|story|email|letter|report|post|content|poem|script|ad|copy)\b/i.test(t)) return 'write';
    if (/\b(explain|what is|how does|describe|what are|define|tell me about|help me understand|teach me)\b/i.test(t)) return 'explain';
    if (/\b(analyze|analyse|evaluate|assess|review|critique|audit)\b/i.test(t)) return 'analyze';
    if (/\b(compare|vs\.?|versus|difference between|better|which one|pros and cons)\b/i.test(t)) return 'compare';
    if (/\b(plan|roadmap|strategy|how to prepare|steps to|guide|schedule|timetable)\b/i.test(t)) return 'plan';
    if (/\b(research|study|investigate|survey|literature|findings|data)\b/i.test(t)) return 'research';
    if (/\b(design|architecture|architect|system design|design pattern)\b/i.test(t)) return 'design';
    if (/\b(translate|convert|transform|change from|rewrite)\b/i.test(t)) return 'transform';
    if (/\b(story|poem|fiction|narrative|character|plot|novel|screenplay)\b/i.test(t)) return 'creative';
    if (/\b(calculate|solve|compute|find|equation|formula|proof)\b/i.test(t)) return 'math';
    if (/\b(brainstorm|ideas|generate ideas|think of|come up with)\b/i.test(t)) return 'brainstorm';
    return 'general';
  }

  function extractSubjects(t, examType) {
    const subjects = [];
    const lower = t.toLowerCase();

    // If GS mentioned with exam context, infer all GS subjects
    if (examType && (/\bgs\b|general studies|general science|general knowledge/.test(lower))) {
      return ['History', 'Polity', 'Geography', 'Economy', 'General Science', 'Current Affairs & Static GK'];
    }

    const patterns = {
      'History': /\bhist(ory)?\b|ancient|medieval|modern india|independence/i,
      'Polity': /\bpolit(y|ical science)\b|constitution|governance|parliament|civics/i,
      'Geography': /\bgeo(graphy)?\b|physical geo|rivers|mountains|climate zone/i,
      'Economy': /\beconom(y|ics)\b|gdp|budget|fiscal|monetary|inflation/i,
      'General Science': /\bscience\b|physics|chemistry|biology|general science/i,
      'Current Affairs': /\bcurrent affairs?\b|daily news|static gk|current events/i,
      'Mathematics': /\bmath(s|ematics)?\b|quantitative|arithmetic|algebra|geometry|calculus/i,
      'English': /\benglish\b|grammar|vocabulary|comprehension|verbal/i,
      'Reasoning': /\breasoning\b|logical|aptitude|mental ability|puzzle/i,
      'Computer Science': /\bcomputer science\b|cs\b|dsa|data structures|algorithms/i,
      'Data Science': /\bdata science\b|machine learning|ml\b|ai\b|deep learning/i,
      'Finance': /\bfinance\b|investing|stocks|trading|portfolio|mutual fund/i,
    };

    for (const [subject, regex] of Object.entries(patterns)) {
      if (regex.test(t)) subjects.push(subject);
    }
    return subjects;
  }

  function extractTechnologies(t) {
    const techs = [];
    const techMap = {
      'Python': /\bpython\b/i, 'JavaScript': /\bjavascript\b|\bjs\b/i,
      'TypeScript': /\btypescript\b|\bts\b/i, 'React': /\breact(\.js)?\b/i,
      'Node.js': /\bnode(\.js)?\b/i, 'Java': /\bjava\b(?! ?script)/i,
      'C++': /\bc\+\+\b/i, 'C#': /\bc#\b/i, 'Go': /\bgolang\b|\bgo\b/i,
      'Rust': /\brust\b/i, 'SQL': /\bsql\b/i, 'PostgreSQL': /\bpostgres(ql)?\b/i,
      'MongoDB': /\bmongodb\b/i, 'Docker': /\bdocker\b/i, 'Kubernetes': /\bkubernetes\b|\bk8s\b/i,
      'AWS': /\baws\b/i, 'Django': /\bdjango\b/i, 'FastAPI': /\bfastapi\b/i,
      'Flutter': /\bflutter\b/i, 'Vue': /\bvue(\.js)?\b/i, 'Angular': /\bangular\b/i,
      'Next.js': /\bnext(\.js)?\b/i, 'GraphQL': /\bgraphql\b/i,
    };
    for (const [tech, regex] of Object.entries(techMap)) {
      if (regex.test(t)) techs.push(tech);
    }
    return techs;
  }

  function extractNamedEntities(t) {
    const entities = { platforms: [], exams: [], locations: [], organizations: [] };
    const platforms = ['unacademy', 'physics wallah', 'pw', 'adda247', 'exampur', 'testbook',
      'gradeup', 'byjus', 'vedantu', 'youtube', 'udemy', 'coursera', 'edx', 'skillshare',
      'github', 'stackoverflow', 'leetcode', 'hackerrank', 'codeforces', 'netflix', 'spotify',
      'amazon', 'flipkart', 'zomato', 'swiggy', 'bsc academy', 'exampur', 'bankers adda'];
    platforms.forEach(p => { if (t.toLowerCase().includes(p)) entities.platforms.push(p); });
    return entities;
  }

  function extractOutputFields(t) {
    // Detect explicitly requested output fields
    const fields = [];
    const fieldPatterns = [
      { key: 'name', regex: /\b(name|full name|teacher name)\b/i },
      { key: 'institute/platform', regex: /\b(institute|platform|organization|channel|academy)\b/i },
      { key: 'experience', regex: /\b(experience|years of experience|years? in teaching|how long)\b/i },
      { key: 'student connect/reach', regex: /\b(student connect|students? connected|followers|subscribers|community)\b/i },
      { key: 'latest batch name', regex: /\b(batch|course name|latest batch|batch name)\b/i },
      { key: 'rating', regex: /\b(rate|rating|score|\/10|out of 10)\b/i },
      { key: 'why suitable', regex: /\b(why|reason|suitable|good for|beneficial)\b/i },
      { key: 'price/cost', regex: /\b(price|cost|fee|charge|paid|free)\b/i },
      { key: 'teaching style', regex: /\b(style|approach|method|technique|way of teaching)\b/i },
      { key: 'unique advantage', regex: /\b(unique|advantage|special|strength|USP|specialty)\b/i },
      { key: 'pros/cons', regex: /\b(pros?|cons?|advantages?|disadvantages?|strengths?|weaknesses?)\b/i },
      { key: 'contact/link', regex: /\b(link|contact|url|website|channel link)\b/i },
    ];
    fieldPatterns.forEach(fp => { if (fp.regex.test(t)) fields.push(fp.key); });
    return fields;
  }

  function extractTimeContext(t) {
    const times = [];
    if (/\bdec(ember)? ?20(25|26)\b|\bdecember 2025\b/i.test(t)) times.push('December 2025');
    if (/\b2026\b/.test(t)) times.push('2026');
    if (/\b2025\b/.test(t)) times.push('2025');
    if (/\brecent(ly)?\b|\blatest\b|\bnew(est)?\b|\bactive\b/i.test(t)) times.push('recent/active');
    if (/\bthis year\b|\bcurrent year\b/i.test(t)) times.push('current year');
    if (/\bupcoming\b|\bfuture\b/i.test(t)) times.push('upcoming');
    return times;
  }

  function extractBudgetContext(t) {
    if (/\bfree\b|no pay|without paying|no cost|open source/i.test(t)) return 'free_only';
    if (/\bno worry (of|about) price\b|price no.*issue|don't care.*price|any price|budget.*no\b/i.test(t)) return 'unlimited';
    if (/\bpaid\b|premium|subscription|buy|purchase|enroll/i.test(t)) return 'paid_ok';
    if (/\bcheap|affordable|low cost|budget|under [\$₹€]/i.test(t)) return 'budget_conscious';
    return 'unspecified';
  }

  function extractCount(t) {
    const m = t.match(/\btop (\d+)\b|\bgive me (\d+)\b|\blist (\d+)\b|\b(\d+) (options?|examples?|ways?|methods?)\b/i);
    if (m) return parseInt(m[1] || m[2] || m[3] || m[4]);
    if (/\bfew\b/i.test(t)) return 3;
    if (/\bseveral\b|\bmany\b/i.test(t)) return 5;
    return null;
  }

  function extractWeaknesses(t) {
    const weaknesses = [];
    if (/\bweak in\b|\bstruggling with\b|\bpoor in\b|\bnot good (at|in)\b|\bdifficult\b|\bhard for me\b/i.test(t)) {
      const weakMatch = t.match(/\bweak in\b[^.]*|struggling with[^.]*/i);
      if (weakMatch) weaknesses.push(weakMatch[0]);
    }
    return weaknesses;
  }

  function extractExplicitConstraints(t) {
    const constraints = [];
    // Look for explicit filters/conditions
    const patterns = [
      /not (?:upsc|too deep|theory heavy|motivation[a]l)\b/i,
      /(?:must|should|only) (?:be|have|include|focus)[^.]+/gi,
      /avoid[^.]+/gi,
      /(?:no|without) [a-zA-Z ]+(?:content|teacher|course|platform)[^.]*/gi,
      /only[^.]+(?:specific|focused|relevant)[^.]*/gi,
    ];
    patterns.forEach(p => {
      const matches = t.match(p) || [];
      constraints.push(...matches.slice(0, 3));
    });
    return constraints;
  }

  function detectDomain(t) {
    const lower = t.toLowerCase();
    if (/\b(ssc|upsc|gate|jee|neet|exam|student|study|syllabus|teacher|batch|coaching)\b/.test(lower)) return 'education';
    if (/\b(code|software|app|api|database|server|frontend|backend|deploy|bug|algorithm|framework)\b/.test(lower)) return 'technology';
    if (/\b(invest|stock|market|trading|portfolio|mutual fund|tax|accounting|finance|revenue)\b/.test(lower)) return 'finance';
    if (/\b(health|medical|doctor|disease|symptom|treatment|diet|fitness|workout|nutrition)\b/.test(lower)) return 'health';
    if (/\b(law|legal|contract|court|rights|regulation|compliance|clause|attorney)\b/.test(lower)) return 'legal';
    if (/\b(travel|trip|flight|hotel|visa|itinerary|destination|tour|vacation)\b/.test(lower)) return 'travel';
    if (/\b(business|startup|strategy|market|marketing|sales|customer|product launch|pitch)\b/.test(lower)) return 'business';
    if (/\b(design|ux|ui|figma|prototype|wireframe|color|typography|branding)\b/.test(lower)) return 'design';
    if (/\b(story|poem|fiction|novel|script|narrative|character|plot|creative write)\b/.test(lower)) return 'creative';
    if (/\b(cook|recipe|ingredient|dish|cuisine|food|meal|bake|restaurant)\b/.test(lower)) return 'food';
    if (/\b(sport|cricket|football|game|player|match|tournament|team|athlete)\b/.test(lower)) return 'sports';
    return 'general';
  }

  // ─── MASTER CONTEXT BUILDER ─────────────────────────────────────────────

  function extractFullContext(text) {
    const lower = text.toLowerCase();
    const action = extractAction(text);
    const examType = extractExamType(text);

    return {
      raw:          text,
      lower:        lower,
      wordCount:    text.split(/\s+/).length,
      personType:   extractPersonType(text),
      examType:     examType,
      examYear:     (text.match(/\b(20[2-9]\d)\b/) || [])[0] || null,
      action:       action,
      domain:       detectDomain(text),
      subjects:     extractSubjects(text, examType),
      technologies: extractTechnologies(text),
      entities:     extractNamedEntities(text),
      outputFields: extractOutputFields(text),
      count:        extractCount(text),
      timeFilters:  extractTimeContext(text),
      budget:       extractBudgetContext(text),
      weaknesses:   extractWeaknesses(text),
      constraints:  extractExplicitConstraints(text),

      // Format hints
      wantsRating:    /\brate|rating|score|\/10|out of 10\b/i.test(text),
      wantsList:      /\btop \d+|list\b|give me|tell me\b/i.test(text),
      wantsTable:     /\btable|tabular|comparison|compare\b/i.test(text),
      wantsSteps:     /\bstep|how to|procedure|roadmap|process\b/i.test(text),
      wantsDecision:  /\bwhich|choose|recommend|best for me|decision\b/i.test(text),
      wantsComparison:/\bcompare|vs\.?|versus|difference|better\b/i.test(text),
      wantsReasoning: /\bwhy|reason|explain|justify\b/i.test(text),
      needsBothTypes: /\bor\b.*(?:combined|all[- ]in[- ]one|individual|separate)/i.test(text),

      // Re-optimize detection
      isAlreadyOptimized: /^##\s+[A-Z🎯🧠⚙️]/m.test(text.trim()),
    };
  }

  // ══════════════════════════════════════════════════════════════════════════
  // DYNAMIC SECTION BUILDERS
  // ══════════════════════════════════════════════════════════════════════════

  // ─── ROLE BUILDER ───────────────────────────────────────────────────────

  function buildRoleForContext(ctx) {
    if (ctx.action === 'recommend' && ctx.domain === 'education' && ctx.examType) {
      const subs = ctx.subjects.length ? ctx.subjects.slice(0, 3).join(', ') : 'core subjects';
      return `You are a **Competitive Exam Expert and Educational Consultant** specializing in **${ctx.examType} examination preparation** in India. You have deep, current knowledge of India's coaching ecosystem — online platforms (Unacademy, PW, Adda247, Exampur, Testbook, BSC Academy, YouTube educators), batch structures, teacher reputations, student results, and which educators are SSC-focused versus UPSC-heavy. You give data-backed, results-oriented recommendations tailored to a student's specific weakness profile.`;
    }
    if (ctx.action === 'recommend' && ctx.domain === 'technology') {
      const techs = ctx.technologies.length ? ctx.technologies.join('/') : 'software development';
      return `You are a **Senior Technology Advisor** with comprehensive knowledge of the ${techs} ecosystem — tools, frameworks, platforms, libraries, and emerging alternatives. You evaluate options based on production-readiness, community support, learning curve, and real-world adoption, not just feature lists.`;
    }
    if (ctx.action === 'debug' || ctx.action === 'code') {
      const lang = ctx.technologies.length ? ctx.technologies[0] : 'software';
      return `You are a **Senior ${lang} Engineer** with 10+ years of production experience. You write clean, maintainable, well-tested code. You don't just fix bugs — you identify root causes, prevent recurrence, and improve the surrounding code quality.`;
    }
    if (ctx.action === 'explain' && ctx.domain === 'education') {
      const sub = ctx.subjects[0] || 'the subject';
      return `You are an **Expert Educator** specializing in ${sub} for ${ctx.examType || 'competitive exam'} preparation. You make complex topics understandable, prioritize exam-relevant content, and build conceptual clarity that translates directly to marks.`;
    }
    if (ctx.action === 'plan' && ctx.domain === 'education') {
      return `You are a **${ctx.examType || 'Competitive Exam'} Strategy Coach** who has guided thousands of aspirants to success. You create realistic, effective, time-bound study plans that account for current weaknesses, available time, and exam pattern requirements.`;
    }
    if (ctx.action === 'research') {
      return `You are a **Research Analyst and Information Synthesist** who transforms scattered data into clear, decision-ready intelligence. You evaluate source quality, identify patterns, surface non-obvious insights, and always ground conclusions in evidence.`;
    }
    if (ctx.action === 'analyze') {
      return `You are a **Critical Analyst** with expertise in ${ctx.domain} domain evaluation. You assess from multiple dimensions — technical, strategic, risk-based, and practical — without bias toward any predetermined conclusion.`;
    }
    if (ctx.action === 'write' || ctx.action === 'creative') {
      return `You are a **Professional Content Creator and Writer** who produces engaging, purpose-driven content tailored to the target audience. You balance creativity with strategic intent, ensuring every piece achieves its communication goal.`;
    }
    if (ctx.action === 'compare') {
      return `You are a **Comparative Analysis Expert** who evaluates options on consistent, relevant criteria. You present balanced assessments with clear recommendations, helping decision-makers choose confidently rather than remain uncertain.`;
    }
    if (ctx.domain === 'finance') {
      return `You are a **Financial Advisor and Market Analyst** with expertise in investment strategy, risk assessment, and financial planning. You give evidence-based, practical financial guidance while clearly noting where professional consultation is required.`;
    }
    if (ctx.domain === 'health') {
      return `You are a **Health and Wellness Expert** who provides science-backed, actionable guidance. You reference medical consensus and evidence-based practices while recommending professional consultation for clinical decisions.`;
    }
    if (ctx.domain === 'business') {
      return `You are a **Business Strategist and Market Expert** with deep expertise in startup growth, competitive positioning, and operational excellence. You bridge theory and execution — every recommendation is implementable, not just conceptual.`;
    }
    // Generic fallback
    return `You are a **Domain Expert and Senior Advisor** with deep expertise in ${ctx.domain === 'general' ? 'your field' : ctx.domain}. You combine theoretical depth with practical real-world experience, producing responses that are accurate, actionable, and context-appropriate.`;
  }

  // ─── OBJECTIVE BUILDER ──────────────────────────────────────────────────

  function buildObjective(input, ctx) {
    const raw = input.trim();
    if (raw.split(/\s+/).length > 30) return raw; // already detailed enough

    // Expand based on action type
    if (ctx.action === 'recommend' && ctx.examType) {
      const subs = ctx.subjects.length ? ctx.subjects.join(', ') : 'all relevant subjects';
      const count = ctx.count || 3;
      const timeStr = ctx.timeFilters.length ? ctx.timeFilters.join(' / ') : 'recent 2025–2026';
      return `Identify and rank the **best ${ctx.examType}-focused teachers/platforms** for an aspirant targeting ${ctx.examType} ${ctx.examYear || 'exam'} who is ${ctx.weaknesses.length ? `specifically weak in ${ctx.weaknesses[0]}` : 'seeking structured guidance'}. Provide Top ${count} recommendations per subject (${subs}) + Top ${count} all-in-one options. All recommendations must have active batches launched ${timeStr}, be ${ctx.examType}-specific (not ${ctx.examType === 'SSC' ? 'UPSC-level depth' : 'off-exam-pattern content'}), and be ranked with full justification including ${ctx.outputFields.length ? ctx.outputFields.join(', ') : 'name, platform, experience, rating, and suitability reasoning'}.`;
    }
    if (ctx.action === 'debug') {
      return `**Debug and fix** the following issue completely: "${raw}". Identify the root cause, not just the symptom. Provide a working solution with explanation of why it broke and how the fix prevents recurrence.`;
    }
    if (ctx.action === 'code') {
      const techs = ctx.technologies.length ? ` using ${ctx.technologies.join('/')}` : '';
      return `**Build a complete, production-ready implementation**${techs} for: "${raw}". Deliver fully working code — not pseudocode, not stubs. Include error handling, edge cases, and clear usage documentation.`;
    }
    if (ctx.action === 'explain') {
      const sub = ctx.subjects[0] || 'the topic';
      return `**Explain "${raw}" comprehensively** — cover the core concept, underlying mechanism, real-world applications, common misconceptions, and ${ctx.examType ? `${ctx.examType} exam-relevant details and frequently tested angles` : 'practical implications'}. Make it stick.`;
    }
    if (ctx.action === 'plan') {
      const examStr = ctx.examType ? `for ${ctx.examType} ${ctx.examYear || 'exam'}` : '';
      return `**Create a detailed, actionable preparation plan** ${examStr} for: "${raw}". The plan must be realistic, time-bound, and account for the current weakness profile. Include priorities, daily/weekly targets, resources, and checkpoints.`;
    }
    if (ctx.action === 'research') {
      return `**Conduct comprehensive research** on: "${raw}". Provide evidence-based findings, multiple perspectives, trend analysis, and clear strategic recommendations — not a generic summary.`;
    }
    if (ctx.action === 'analyze') {
      return `**Perform a thorough, multi-dimensional analysis** of: "${raw}". Evaluate from technical, strategic, risk, and practical angles. Surface non-obvious insights and deliver specific, actionable conclusions.`;
    }
    if (ctx.action === 'compare') {
      return `**Provide a rigorous comparison** of: "${raw}". Evaluate on consistent criteria, present trade-offs clearly, and end with a definitive recommendation for different use cases.`;
    }
    if (ctx.action === 'write' || ctx.action === 'creative') {
      return `**Create a polished, professional piece** for: "${raw}". Ensure it achieves its purpose, resonates with the target audience, and is immediately usable without further editing.`;
    }

    return `Provide a **comprehensive, expert-level response** to: "${raw}". Cover all relevant dimensions, surface non-obvious insights, and deliver conclusions that are immediately actionable.`;
  }

  // ─── CONTEXT SECTION BUILDER ────────────────────────────────────────────

  function buildContextSection(input, ctx) {
    const lines = [];

    // Person profile
    if (ctx.examType) {
      lines.push(`- **Aspirant Profile:** ${ctx.examType} ${ctx.examYear || 'exam'} target, ${ctx.personType === 'exam_aspirant' ? 'serious competitive exam aspirant' : 'student'}`);
    } else if (ctx.personType !== 'general') {
      const typeMap = { developer: 'Software developer/engineer', student: 'Student/learner', researcher: 'Researcher/analyst', business: 'Business professional', designer: 'Designer/creative', writer: 'Content creator/writer', medical: 'Medical/healthcare professional' };
      lines.push(`- **User Profile:** ${typeMap[ctx.personType] || ctx.personType}`);
    }

    // Weakness/challenges
    if (ctx.weaknesses.length) {
      lines.push(`- **Current Challenge:** ${ctx.weaknesses.join('; ')}`);
    }

    // Subjects
    if (ctx.subjects.length) {
      lines.push(`- **Subjects/Topics in Scope:** ${ctx.subjects.join(', ')}`);
    }

    // Technologies
    if (ctx.technologies.length) {
      lines.push(`- **Technology Stack:** ${ctx.technologies.join(', ')}`);
    }

    // Time context
    if (ctx.timeFilters.length) {
      lines.push(`- **Recency Requirement:** ${ctx.timeFilters.join(' / ')} — only current, active, relevant content`);
    }

    // Budget
    const budgetMap = { unlimited: 'No budget constraint — paid options fully acceptable', free_only: 'Free resources only', paid_ok: 'Paid resources acceptable', budget_conscious: 'Budget-conscious — value-for-money important' };
    if (ctx.budget !== 'unspecified') {
      lines.push(`- **Budget Context:** ${budgetMap[ctx.budget]}`);
    }

    // Platforms mentioned
    if (ctx.entities.platforms.length) {
      lines.push(`- **Known Platforms/Context:** ${ctx.entities.platforms.join(', ')}`);
    }

    // Domain context
    const domainContextMap = {
      education: 'Indian competitive exam ecosystem — coaching platforms, YouTube educators, structured batches',
      technology: 'Real-world production environment — scalability, maintainability, performance matter',
      finance: 'Financial decision-making context — risk, returns, tax implications all relevant',
      health: 'Health and wellness — evidence-based guidance, professional referral where appropriate',
      business: 'Commercial/professional environment — ROI, scalability, execution feasibility matter',
      general: 'Practical, real-world application context',
    };
    lines.push(`- **Environmental Context:** ${domainContextMap[ctx.domain] || domainContextMap.general}`);

    // User's explicit constraints
    if (ctx.constraints.length) {
      lines.push(`- **Explicit Requirements:** ${ctx.constraints.slice(0, 3).join('; ')}`);
    }

    return lines.join('\n');
  }

  // ─── EXECUTION STEPS BUILDER ────────────────────────────────────────────

  function buildExecutionSteps(ctx) {
    const examType = ctx.examType || 'competitive exam';

    // Teacher/Course recommendation for exam prep
    if (ctx.action === 'recommend' && ctx.domain === 'education' && ctx.examType) {
      const count = ctx.count || 3;
      const subs = ctx.subjects.slice(0, 6);
      return [
        `**Aspirant Need Assessment** — Map the specific gaps: what does "weak in ${ctx.subjects[0] || 'GS'}" mean at ${examType} level? PYQ accuracy, conceptual gaps, or coverage? This defines evaluation criteria`,
        `**${examType} Ecosystem Survey** — Identify all major platforms with active ${examType}-specific content: YouTube, Unacademy, PW, Adda247, Exampur, Testbook, Gradeup, BSC, individual educators with ${ctx.timeFilters.length ? ctx.timeFilters[0] : '2025/2026'} active batches`,
        `**Subject-wise Teacher Shortlisting** — For each subject (${subs.join(', ')}): screen for ${examType} relevance, NOT ${ctx.examType === 'SSC' ? 'UPSC-level theory depth' : 'off-pattern content'}, PYQ coverage, structured syllabus`,
        `**Recency & Activity Verification** — Filter: only teachers with batches active or launched ${ctx.timeFilters.length ? ctx.timeFilters.join('/') : 'Dec 2025–2026'}. Inactive educators removed regardless of past reputation`,
        `**Multi-criteria Evaluation** — Score each teacher on: ${examType} pattern alignment | PYQ coverage | revision system | doubt clearing | student results | teaching style (conceptual/PYQ-based/tricks-focused)`,
        `**Student Reach & Connect Analysis** — Evaluate community quality: subscriber count with engagement metrics, doubt resolution speed, alumni results, batch size, response system`,
        `**All-in-One Package Research** — Separately evaluate combined GS packages for students preferring single-teacher consistency over subject specialists`,
        `**Objective Rating Derivation** — Assign /10 ratings with explicit criteria: ${ctx.wantsRating ? 'weighted score across all factors, not arbitrary' : 'relative ranking with justification'}. No famous-name bias — only merit`,
        `**Suitability Mapping** — Match each teacher's specific strengths to the profile: student weak in ${ctx.subjects[0] || 'GS'}, targeting ${ctx.examYear || 'next'} exam — who helps most efficiently`,
        `**Decision Framework Output** — Generate: single best recommendation + best combination + "who should choose whom" guide for different student profiles (time-constrained, budget-flexible, conceptually weak, etc.)`,
      ];
    }

    // Debugging
    if (ctx.action === 'debug') {
      const tech = ctx.technologies[0] || 'the codebase';
      return [
        `**Symptom Documentation** — Precisely describe what is failing: error message, stack trace, what was expected vs. what happened, when it started`,
        `**Environment Analysis** — State ${tech} version, OS, dependencies, runtime environment. Many bugs are environment-specific`,
        `**Root Cause Isolation** — Trace the error backward from symptom to origin. Don't treat symptoms — find the actual cause`,
        `**Minimal Reproduction** — Strip down to smallest code that reproduces the issue. This eliminates noise and confirms the root cause`,
        `**Fix Implementation** — Write the corrected code. Explain WHY this is the fix, not just what changed`,
        `**Regression Check** — Verify the fix doesn't break adjacent functionality. What could this change affect?`,
        `**Prevention Strategy** — How should this type of bug be prevented going forward? Tests, validation, linting rules?`,
        `**Code Quality Review** — While in the area, flag any related code smells or anti-patterns worth addressing`,
        `**Documentation Update** — What comments, README, or documentation should be updated to reflect this fix?`,
        `**Testing Verification** — Provide test cases that would have caught this bug and confirm the fix`,
      ];
    }

    // Code implementation
    if (ctx.action === 'code' || ctx.action === 'design') {
      const tech = ctx.technologies.join(', ') || 'the chosen technology';
      return [
        `**Requirements Parsing** — Extract functional requirements, non-functional requirements, constraints, and implicit expectations from the brief`,
        `**Technology Selection** — Justify ${tech} choice or determine optimal stack. What patterns, libraries, architectural styles apply?`,
        `**Architecture Design** — Design the system structure BEFORE coding: components, interfaces, data flow, state management`,
        `**Edge Case Enumeration** — List all non-happy-path scenarios: null inputs, empty state, maximum load, concurrent access, network failure`,
        `**Core Implementation** — Write clean, well-structured code. Self-documenting names. One function = one responsibility`,
        `**Input Validation Layer** — Validate all inputs at boundaries. What can go wrong before execution begins?`,
        `**Error Handling** — Comprehensive try/catch/finally. Meaningful error messages. Graceful degradation`,
        `**Testing Suite** — Unit tests for core logic, integration tests for interfaces, edge case tests for identified scenarios`,
        `**Performance Analysis** — Time/space complexity. Identify bottlenecks. Optimize only where measured, not by intuition`,
        `**Documentation & Usage** — Clear usage examples, API documentation, known limitations, and extension points`,
      ];
    }

    // Explanation/teaching
    if (ctx.action === 'explain') {
      const sub = ctx.subjects[0] || 'the concept';
      const exam = ctx.examType ? ` for ${ctx.examType}` : '';
      return [
        `**Core Definition** — Precise, unambiguous definition of the concept. What is it? What is it NOT? Draw the boundary clearly`,
        `**Historical/Contextual Background** — Why does this exist? What problem does it solve? What preceded it?${exam ? ` When/how does it appear in ${examType} papers?` : ''}`,
        `**Fundamental Mechanism** — How does it actually work? Explain the underlying process step by step`,
        `**Concrete Examples** — 2-3 real-world examples that make the concept tangible and memorable`,
        `**Analogical Mapping** — Connect to something the reader definitely already knows. Good analogies are unforgettable`,
        `**Common Misconceptions** — What do most people get wrong about this? Proactively address the top 3 mistakes${exam ? ` and examiner traps` : ''}`,
        `**${ctx.examType ? `${ctx.examType} Exam Angle` : 'Application'}** — ${ctx.examType ? `How examiners test this: question types, common MCQ traps, PYQ analysis, scoring strategy` : 'Real-world applications and when to use this knowledge'}`,
        `**Connections & Dependencies** — How does this relate to adjacent concepts? What must you understand to fully grasp this?`,
        `**Quick Recall System** — Mnemonics, memory tricks, or visual anchors that make this stick under exam pressure`,
        `**Summary & Self-Check** — 3-point summary + 1-2 questions the reader should be able to answer after reading`,
      ];
    }

    // Study/preparation planning
    if (ctx.action === 'plan') {
      const exam = ctx.examType || 'the exam';
      return [
        `**Current State Assessment** — Honestly evaluate: current level in each subject, available daily study hours, time remaining to ${exam}, past attempt analysis if applicable`,
        `**${exam} Pattern Deep-dive** — What does the exam actually test? Subject weightage, question types, difficulty distribution, sectional cutoffs`,
        `**Priority Matrix** — Rank topics by: marks weightage × current weakness × improvement speed. High-weight, high-weakness, fast-improvement topics come first`,
        `**Resource Allocation** — Assign specific resources per subject: which teacher/book/app for each. Don't overwhelm with too many sources`,
        `**Daily/Weekly Schedule** — Break into concrete daily targets. Buffer days for revision. No abstract goals like "study hard"`,
        `**Milestone Setting** — Monthly checkpoints with specific, measurable targets. What should you be able to do by Day 30, 60, 90?`,
        `**Mock Test Integration** — Schedule sectional mocks (after topics) and full mocks (every 2 weeks from 60 days out). Analysis protocol for each`,
        `**Weak Area Recovery Plan** — Specific strategy for identified weaknesses. What extra practice, how many hours, by when?`,
        `**Revision Architecture** — Spaced repetition schedule for notes, formulas, and current affairs. Revision is not re-reading`,
        `**Contingency & Stress Protocol** — What to do if you fall behind the schedule? How to handle exam day anxiety and time management?`,
      ];
    }

    // Research
    if (ctx.action === 'research') {
      return [
        `**Research Scope Boundary** — Define precisely: what question is being answered? What is in scope and out of scope? What does a complete answer look like?`,
        `**Information Architecture** — What categories of evidence would comprehensively answer this? Primary vs. secondary sources. Quantitative vs. qualitative`,
        `**Data Collection** — Gather information from diverse, credible sources. Note source quality, recency, and potential bias for each`,
        `**Synthesis & Thematic Clustering** — Group related findings into coherent themes. Which evidence is consistent? Where do sources diverge?`,
        `**Comparative Analysis** — Evaluate across options/perspectives on consistent criteria. Apply the same standards to all`,
        `**Pattern & Anomaly Identification** — What trends emerge? What seems counterintuitive? What needs deeper investigation?`,
        `**Strengths/Weaknesses Assessment** — Balanced evaluation: what works, what doesn't, for whom, under what conditions`,
        `**Risk & Uncertainty Mapping** — What remains unknown? Where is evidence weak? What assumptions could invalidate the conclusions?`,
        `**Trend Projection** — Based on current trajectory, where is this heading? What signals indicate direction of change?`,
        `**Strategic Recommendation** — Evidence-backed conclusions with confidence levels. Specific next steps ranked by priority`,
      ];
    }

    // Analysis
    if (ctx.action === 'analyze') {
      return [
        `**Framing the Analysis** — Define the evaluation criteria upfront. What does "good" look like for this specific context?`,
        `**Structural Decomposition** — Break the subject into its component parts. Analyze each independently before synthesizing`,
        `**Technical Depth** — Examine internals, mechanisms, implementation details — not just surface behavior`,
        `**Stakeholder/Impact Mapping** — Who is affected? How? What are second-order effects beyond the obvious?`,
        `**Comparative Benchmarking** — Against what is this being evaluated? Industry standards, alternatives, historical performance?`,
        `**Strengths Identification** — What genuinely works well and why? Evidence-backed, not cheerleading`,
        `**Weakness & Gap Analysis** — What is missing, broken, or suboptimal? Specific and actionable identification`,
        `**Risk Assessment** — What can go wrong? Likelihood vs. impact matrix. Known unknowns vs. unknown unknowns`,
        `**Optimization Opportunities** — Specific improvements ranked by: impact vs. effort. What's the highest-leverage change?`,
        `**Synthesis & Verdict** — Integrate all dimensions into a clear, decisive overall assessment with confidence level`,
      ];
    }

    // Generic fallback (better than old generic steps)
    const domain = ctx.domain;
    return [
      `**Problem/Question Framing** — Restate the core ask in precise terms. What exactly is being solved? What would a complete answer look like?`,
      `**Contextual Analysis** — Understand the ${domain} domain context. What constraints, norms, and best practices apply?`,
      `**Information Gathering** — What knowledge is needed? Identify key concepts, data points, and relevant precedents`,
      `**Structured Breakdown** — Decompose into component parts. Address each systematically before synthesizing`,
      `**Core Response Development** — Build the main answer with precision. Every claim supported by reasoning or evidence`,
      `**Edge Cases & Exceptions** — What doesn't fit the main pattern? Surface exceptions and boundary conditions`,
      `**Alternative Approaches** — What other valid approaches exist? What are the trade-offs?`,
      `**Practical Application** — How does this apply in real ${domain} scenarios? Ground all theory in practice`,
      `**Risk & Limitation Awareness** — What are the limitations of this answer? Where should additional expertise be sought?`,
      `**Actionable Summary** — What should the reader DO with this information? Specific next steps`,
    ];
  }

  // ─── CONSTRAINTS BUILDER ────────────────────────────────────────────────

  function buildConstraints(ctx) {
    const dos = [], donts = [];

    if (ctx.action === 'recommend' && ctx.examType) {
      const exam = ctx.examType;
      dos.push(
        `Only include teachers/resources with verifiably active batches in ${ctx.timeFilters.length ? ctx.timeFilters.join('/') : '2025–2026'}`,
        `Ensure all recommendations are ${exam}-pattern specific — syllabus, question style, difficulty level aligned to ${exam}`,
        `Include teachers known for ACTUAL exam results, not just large YouTube subscriber counts`,
        `Provide distinct, specific justification for each rating — not generic praise`,
        `Cover both individual-subject specialists AND all-in-one options`,
      );
      donts.push(
        `Do NOT include ${exam === 'SSC' ? 'UPSC-heavy teachers with excessive theory depth' : 'off-pattern content creators'} regardless of fame`,
        `Do NOT recommend teachers with no verifiable recent batches or outdated content`,
        `Do NOT give identical generic descriptions — each teacher must have specific distinguishing traits`,
        `Do NOT skip the rating justification — "/10 because XYZ specific reason" is required`,
        `Do NOT recommend motivational YouTubers without concrete exam-focused content structure`,
      );
    } else if (ctx.action === 'code' || ctx.action === 'debug') {
      dos.push(
        'Provide complete, runnable code — no pseudocode, no "you can extend this" stubs',
        'Follow language-specific best practices and naming conventions',
        'Include error handling for all failure modes identified',
        'Add comments for non-obvious logic — never for obvious operations',
        'Test cases must cover: happy path, edge cases, and at least one failure scenario',
      );
      donts.push(
        'Do NOT omit error handling or leave try/catch blocks empty',
        'Do NOT use deprecated APIs or outdated patterns',
        'Do NOT optimize prematurely — correctness before performance',
        'Do NOT provide solutions without explaining the root cause (for debugging)',
        'Do NOT skip edge case handling — empty inputs, null values, boundary conditions',
      );
    } else if (ctx.action === 'research' || ctx.action === 'analyze') {
      dos.push(
        'Ground all claims in evidence — cite specific reasons, not vague assertions',
        'Present all major perspectives before drawing conclusions',
        'Quantify where possible — avoid vague superlatives ("best", "most") without data',
        'Explicitly state confidence level: high (strong evidence) | medium (reasonable inference) | low (speculation)',
        'Include risks and limitations of your own analysis',
      );
      donts.push(
        'Do NOT cherry-pick only supporting evidence — address contradictory evidence',
        'Do NOT make unsupported claims presented as facts',
        'Do NOT bias conclusions toward what sounds impressive or safe',
        'Do NOT use corporate/academic jargon to hide lack of substance',
        'Do NOT omit the "what could go wrong" dimension',
      );
    } else {
      dos.push(
        'Be specific and precise — vague responses are useless',
        'Structure the response clearly with headers for multi-part answers',
        'Ground explanations in concrete examples or analogies',
        'Acknowledge limitations and edge cases explicitly',
        'Prioritize actionability — what can the reader DO with this?',
      );
      donts.push(
        'Do NOT be vague or repeat the question as the answer',
        'Do NOT omit important caveats or exceptions',
        'Do NOT use filler phrases: "great question", "certainly", "of course"',
        'Do NOT truncate — complete the full response',
        'Do NOT confuse confidence with certainty — distinguish them clearly',
      );
    }

    return { dos, donts };
  }

  // ─── OUTPUT SPEC BUILDER ────────────────────────────────────────────────

  function buildOutputSpec(ctx) {
    const lines = [];

    if (ctx.action === 'recommend' && ctx.domain === 'education' && ctx.examType) {
      const count = ctx.count || 3;
      const fields = ctx.outputFields.length ? ctx.outputFields : ['Name', 'Institute/Platform', 'Experience', 'Student Reach', 'Latest Batch (with launch date)', 'Teaching Style', 'Rating /10 with justification', 'Why suitable for weak GS student', 'Unique Advantage'];

      lines.push(`**Structure:**`);
      lines.push(`1. **Individual Subject Teachers** — Top ${count} per subject`);
      if (ctx.subjects.length) {
        ctx.subjects.forEach(s => lines.push(`   - ${s}: Teacher 1 → Teacher 2 → Teacher 3`));
      }
      lines.push(`2. **All-in-One GS Teachers/Platforms** — Top ${count}`);
      lines.push(``);
      lines.push(`**For Each Teacher, include:**`);
      fields.forEach(f => lines.push(`- ${f}`));
      lines.push(``);
      lines.push(`**Conclude with:**`);
      lines.push(`- 🏆 Single Best Overall Recommendation (with specific reason)`);
      lines.push(`- 🔗 Best Combination Strategy (if multiple teachers give better coverage)`);
      lines.push(`- 📊 Decision Guide: "Which type of student should choose which teacher"`);
    } else if (ctx.action === 'code' || ctx.action === 'debug') {
      lines.push(`1. **Architecture Overview** (3–5 sentences on the approach and why)`);
      lines.push(`2. **Complete Implementation** (fenced code block with language tag, inline comments)`);
      lines.push(`3. **Usage Examples** (realistic input → output demonstrations)`);
      lines.push(`4. **Test Cases** (happy path + ${ctx.action === 'debug' ? 'regression test for the fixed bug' : '3 edge cases + 1 failure scenario'})`);
      lines.push(`5. **Complexity & Limitations** (time/space complexity, known limitations)`);
    } else if (ctx.action === 'plan') {
      lines.push(`1. **Current State Analysis** (honest assessment)`);
      lines.push(`2. **Priority Matrix** (subjects/topics ranked by urgency)`);
      lines.push(`3. **Week-by-Week Plan** (concrete, specific targets)`);
      lines.push(`4. **Resource List** (specific books/teachers/apps per subject)`);
      lines.push(`5. **Mock Test Schedule** (dates + what to measure)`);
      lines.push(`6. **60-Day + 30-Day Countdown Checklist**`);
    } else if (ctx.wantsList && ctx.count) {
      lines.push(`**Ranked List:** Top ${ctx.count} options`);
      lines.push(`**Each entry must include:** name/title, key characteristics, specific reason for this rank`);
      if (ctx.wantsRating) lines.push(`**Rating:** /10 with explicit justification per item`);
      if (ctx.wantsDecision) lines.push(`**End with:** Clear recommendation for different use cases`);
    } else if (ctx.wantsComparison) {
      lines.push(`**Comparison Table** — side-by-side on consistent criteria`);
      lines.push(`**Verdict per use case** — who should choose what and why`);
      lines.push(`**Overall winner** — with stated assumptions`);
    } else if (ctx.wantsSteps) {
      lines.push(`**Numbered, sequential steps** — each step actionable on its own`);
      lines.push(`**Expected outcome** after each major phase`);
      lines.push(`**Common mistakes** to avoid at each step`);
    } else {
      lines.push(`**Structured response** with clear section headers`);
      lines.push(`**Each section adds new value** — zero redundancy`);
      lines.push(`**Ends with:** Key Takeaways (3–5 bullets) + Immediate Next Steps`);
    }

    return lines.join('\n');
  }

  // ══════════════════════════════════════════════════════════════════════════
  // MODE BUILDERS
  // ══════════════════════════════════════════════════════════════════════════

  // ─── SIMPLE MODE (most important fix) ──────────────────────────────────
  // Produces clean, expanded natural language — NO markdown headers
  // Like the SSC example the user provided

  function buildSimplePrompt(input, ctx) {
    const parts = [];

    // 1. Identity + Goal statement
    if (ctx.personType === 'exam_aspirant' || ctx.examType) {
      const weakStr = ctx.weaknesses.length ? ` and I am specifically weak in ${ctx.weaknesses[0]}` : '';
      parts.push(`I am a${ctx.examType ? ` ${ctx.examType} aspirant` : ' competitive exam student'} targeting ${ctx.examType || 'my upcoming exam'} ${ctx.examYear ? `in ${ctx.examYear}` : ''}${weakStr}. ${input.charAt(0).toUpperCase() + input.slice(1)}`);
    } else {
      parts.push(input.charAt(0).toUpperCase() + input.slice(1).trim());
    }

    parts.push('');

    // 2. Expand the core request with specifics
    if (ctx.action === 'recommend' && ctx.examType) {
      const count = ctx.count || 3;
      const subs = ctx.subjects.length ? ctx.subjects : ['all relevant subjects'];

      parts.push(`I need highly exam-relevant, ${ctx.examType}-pattern-specific teacher recommendations — not general educators or UPSC-level content.`);
      parts.push('');

      if (ctx.subjects.length) {
        parts.push(`**Please break down into the following subjects:**`);
        ctx.subjects.forEach(s => parts.push(`- ${s}`));
        parts.push('');
      }

      if (ctx.needsBothTypes) {
        parts.push(`Provide recommendations for **both**:`);
        parts.push(`- **Individual subject specialists** (Top ${count} per subject) — for students who prefer subject-specific depth`);
        parts.push(`- **All-in-one combined GS teachers/platforms** (Top ${count} total) — for students preferring single-teacher continuity`);
        parts.push('');
      }

      // Output fields
      const fields = ctx.outputFields.length ? ctx.outputFields : ['Full name', 'Institute or Platform', 'Years of teaching experience', 'Student community size and engagement level', 'Name of their latest batch (especially launched Dec 2025 or 2026)', 'Teaching style (PYQ-based / conceptual / mixed)', 'Rating out of 10 with specific justification', 'Why this teacher is suitable for a weak student targeting ' + ctx.examType, 'Any unique advantage (proven results, notes quality, revision system, tricks)'];
      parts.push(`**For every teacher, include:**`);
      fields.forEach(f => parts.push(`- ${f}`));
      parts.push('');

      // Quality filters
      parts.push(`**Only include teachers who:**`);
      parts.push(`- Are ${ctx.examType}-focused — not primarily UPSC, CAT, or other exam-oriented`);
      if (ctx.timeFilters.length) {
        parts.push(`- Have active or recently started batches (${ctx.timeFilters.join(' / ')})`);
      }
      parts.push(`- Are known for real results, structured content, and exam-pattern coverage`);
      parts.push(`- Prioritize PYQs, high-yield topics, revision, and scoring strategies`);
      parts.push('');

      parts.push(`**Avoid:**`);
      parts.push(`- Teachers who are famous on YouTube but not ${ctx.examType}-specific`);
      parts.push(`- Motivational content creators with little actual teaching structure`);
      if (ctx.timeFilters.length) {
        parts.push(`- Inactive teachers or outdated batches (pre-${ctx.timeFilters[0]})`);
      }
      parts.push('');

      // Budget context
      if (ctx.budget === 'unlimited') {
        parts.push(`Budget is not a constraint — paid batches from any platform are fully acceptable.`);
        parts.push('');
      }

      // Decision guide
      parts.push(`**End the answer with:**`);
      parts.push(`1. **Best Overall Pick** — single final recommendation with clear reason`);
      parts.push(`2. **Best Combination** — if combining 2+ teachers gives better coverage`);
      parts.push(`3. **Decision Guide** — which type of student should choose which teacher/approach`);
      parts.push('');
      parts.push(`Make the response practical and decision-oriented — I should be able to choose confidently without further research.`);

    } else if (ctx.action === 'code' || ctx.action === 'debug') {
      const techs = ctx.technologies.length ? ` using ${ctx.technologies.join('/')}` : '';
      parts.push(`Please provide a **complete, production-ready solution**${techs}.`);
      parts.push('');
      parts.push(`**Requirements:**`);
      parts.push(`- Fully working code, no placeholders or pseudocode`);
      parts.push(`- Comprehensive error handling for all failure modes`);
      parts.push(`- Input validation for edge cases (null, empty, invalid types, boundary values)`);
      parts.push(`- Inline comments for non-obvious logic`);
      parts.push(`- At least 3 test cases: happy path, edge case, and failure scenario`);
      parts.push('');
      parts.push(`**Include:**`);
      parts.push(`- Brief explanation of the approach chosen`);
      parts.push(`- Time and space complexity analysis`);
      parts.push(`- One usage example with realistic input/output`);
      if (ctx.action === 'debug') {
        parts.push(`- Root cause explanation (not just what changed, but WHY it was failing)`);
        parts.push(`- How to prevent this type of bug going forward`);
      }

    } else if (ctx.action === 'explain') {
      const sub = ctx.subjects[0] || 'this topic';
      const examStr = ctx.examType ? ` for ${ctx.examType} preparation` : '';
      parts.push(`Please explain this comprehensively${examStr}, covering:`);
      parts.push(`- Precise definition and what it is NOT`);
      parts.push(`- Why it exists and what problem it solves`);
      parts.push(`- How it works (underlying mechanism)`);
      parts.push(`- 2–3 real-world examples that make it memorable`);
      parts.push(`- Common misconceptions and what people often get wrong`);
      if (ctx.examType) {
        parts.push(`- How this appears in ${ctx.examType} exams: question formats, common MCQ traps, PYQ examples`);
        parts.push(`- Memory tricks or mnemonics for exam recall`);
      }
      parts.push(`- Summary in 3 bullet points`);

    } else if (ctx.action === 'plan') {
      const examStr = ctx.examType ? ` for ${ctx.examType} ${ctx.examYear || 'exam'}` : '';
      parts.push(`Please create a **detailed, realistic preparation plan**${examStr}, including:`);
      parts.push(`- Current state assessment and gap analysis`);
      parts.push(`- Topic priority matrix (high-yield topics first)`);
      if (ctx.subjects.length) {
        parts.push(`- Subject-specific plan for: ${ctx.subjects.join(', ')}`);
      }
      parts.push(`- Daily and weekly study schedule (specific, not vague)`);
      parts.push(`- Specific resources: which teacher/book/app for each subject`);
      parts.push(`- Mock test schedule with analysis protocol`);
      parts.push(`- 30-day, 60-day, and 90-day milestones`);
      parts.push(`- What to do if you fall behind the schedule`);

    } else if (ctx.action === 'compare') {
      parts.push(`Please compare these comprehensively, covering:`);
      parts.push(`- Side-by-side comparison on the most important criteria`);
      parts.push(`- Specific strengths and weaknesses of each`);
      parts.push(`- Which is better for which use case`);
      parts.push(`- Your final recommendation with clear reasoning`);

    } else {
      // Generic expansion
      const keyDetails = [];
      if (ctx.subjects.length) keyDetails.push(`covering: ${ctx.subjects.join(', ')}`);
      if (ctx.wantsRating) keyDetails.push(`with ratings and justification`);
      if (ctx.count) keyDetails.push(`listing the top ${ctx.count}`);
      if (ctx.wantsDecision) keyDetails.push(`with a clear final recommendation`);
      if (keyDetails.length) {
        parts.push(`Please ensure the response is comprehensive, ${keyDetails.join(', ')}.`);
      }

      if (ctx.outputFields.length) {
        parts.push('');
        parts.push(`For each item, include: ${ctx.outputFields.join(', ')}.`);
      }

      if (ctx.timeFilters.length) {
        parts.push(`Focus on ${ctx.timeFilters.join('/')} information — older or outdated content should be noted.`);
      }

      parts.push('');
      parts.push(`Make the response structured, specific, and immediately actionable.`);
    }

    return parts.filter(Boolean).join('\n');
  }

  // ─── ADVANCED MODE ──────────────────────────────────────────────────────

  function buildAdvancedPrompt(input, ctx) {
    const role     = buildRoleForContext(ctx);
    const obj      = buildObjective(input, ctx);
    const ctxSec   = buildContextSection(input, ctx);
    const steps    = buildExecutionSteps(ctx);
    const constr   = buildConstraints(ctx);
    const outSpec  = buildOutputSpec(ctx);

    const examStr  = ctx.examType ? ` (${ctx.examType})` : '';
    const domainStr = ctx.domain !== 'general' ? ctx.domain : 'relevant domain';

    return `## 🧠 ROLE DEFINITION

${role}

**Operating Standards:**
- Accuracy first — no speculation presented as fact
- Depth calibrated to context — not surface-level, not unnecessarily verbose
- Actionable by default — every insight must be usable
- Context-aware — responses fit this specific user's situation, not a generic scenario

---

## 🎯 OBJECTIVE

${obj}

---

## 📋 CONTEXT PARAMETERS

${ctxSec}

---

## ⚙️ EXECUTION PIPELINE

Work through each step in sequence — each builds on the previous:

${steps.map((s, i) => `${i+1}. ${s}`).join('\n')}

---

## ⚠️ CONSTRAINTS

**Must Do:**
${constr.dos.map(d => `- ${d}`).join('\n')}

**Must NOT Do:**
${constr.donts.map(d => `- ${d}`).join('\n')}

---

## ✍️ WRITING & RESPONSE STYLE

- **Tone:** ${ctx.domain === 'education' ? 'Clear, direct, student-friendly — practical over academic' : ctx.domain === 'technology' ? 'Technical, precise, engineering-grade' : ctx.domain === 'business' ? 'Professional, strategic, executive-level' : 'Informative, structured, evidence-backed'}
- **Density:** Dense but readable — every sentence carries information, no filler
- **Terminology:** Use ${domainStr}-appropriate precise language; define specialized terms on first use
- **Structure:** Hierarchical — general principle → specific detail → edge case
- **Confidence calibration:** Be decisive where evidence supports it; qualify clearly where it doesn't

---

## 📐 OUTPUT SPECIFICATION

${outSpec}

---

## ✅ QUALITY REQUIREMENTS

Before finalizing your response, verify:
- [ ] Every execution step is addressed (none skipped)
- [ ] All items have specific, distinct descriptions — no generic copy-paste content
- [ ] ${ctx.wantsRating ? 'Ratings have specific justifications — not arbitrary numbers' : 'Claims are supported by specific reasoning or evidence'}
- [ ] Response is complete — nothing left for "you can research further"
- [ ] ${ctx.examType ? `All recommendations are genuinely ${ctx.examType}-specific, not repurposed UPSC/generic content` : 'All recommendations are actionable in the user\'s specific context'}
- [ ] Ends with clear next steps or decision support`;
  }

  // ─── BASIC MODE ─────────────────────────────────────────────────────────

  function buildBasicPrompt(input, ctx) {
    const sub = ctx.subjects[0] || ctx.domain !== 'general' ? ctx.domain : 'this topic';
    const examStr = ctx.examType ? ` for ${ctx.examType}` : '';

    return `## 🧑‍🏫 ROLE

You are a **patient, encouraging teacher** who makes complex concepts simple. Your superpower is zero-jargon clarity — you build understanding from absolute scratch. No background knowledge assumed. Your student should understand completely after one read.

**Teaching Philosophy:** One idea at a time. Never introduce two unfamiliar terms simultaneously. Every explanation leads somewhere the student can act on.

---

## 🎯 WHAT TO EXPLAIN

${buildObjective(input, ctx)}

**After reading your response, the student should be able to:**
- Explain this concept to someone else in plain words
- Know exactly why it matters${examStr ? ` and how it appears in ${ctx.examType} exams` : ''}
- Never be confused by this topic again

---

## 📋 STUDENT PROFILE

- **Starting Level:** Zero — assume zero prior exposure
- **Goal:** Complete understanding, not just familiarity
- **Language:** Plain English — if a simpler word exists, use it
- **Context:** ${ctx.domain !== 'general' ? ctx.domain + ' domain' : 'General knowledge'}${ctx.examType ? `, ${ctx.examType} exam preparation` : ''}

---

## 📚 EXPLANATION STEPS (all 8 required)

**Step 1 — Define Every Term**
Before using any word, define it. If the definition contains a technical term, define that too. Zero jargon left undefined.

**Step 2 — The WHY (Purpose)**
Why does this exist? What problem does it solve? Make the motivation crystal clear before explaining the mechanism.

**Step 3 — Simple Explanation (The WHAT)**
One or two plain sentences: what IS this? Explain like the student is encountering it for the first time.

**Step 4 — Step-by-Step Breakdown**
Walk through exactly how it works. Number each step. Never combine two actions in one step.

**Step 5 — Real Analogy**
Connect to something the student definitely already knows. A great analogy creates permanent memory.

**Step 6 — Visual Interpretation**
How would you draw this on a whiteboard? Describe the picture: "Imagine a box on the left… an arrow going to…"

**Step 7 — One Level Deeper**
Introduce ONE slightly more advanced element. Build confidence by showing there's more to discover.

**Step 8 — Summary + Self-Check**
📌 Three things to remember
One question the student should now be able to answer

---

## ✍️ STYLE RULES

- Maximum 18 words per sentence
- Never say "as you know" or "obviously" or "simply"
- Short paragraphs — max 4 lines
- Bold every new term on first mention
- Warm, encouraging tone throughout

---

## ✅ BEFORE FINISHING

- [ ] Is there any jargon left unexplained?
- [ ] Can a true beginner understand this in one read?
- [ ] Is the analogy accurate and actually helpful?
- [ ] Does the summary capture the 3 most important things?`;
  }

  // ─── CODE MODE ──────────────────────────────────────────────────────────

  function buildCodePrompt(input, ctx) {
    const tech = ctx.technologies.length ? ctx.technologies.join(', ') : 'optimal technology for the task';
    const obj  = buildObjective(input, ctx);
    const steps = buildExecutionSteps(ctx);
    const constr = buildConstraints(ctx);

    return `## 🛠️ ROLE

You are a **Senior Software Engineer** and **Production Code Specialist**. You write code that ships to production, survives edge cases, and gets approved in peer review. No stubs. No "TODO: handle this case." No pseudocode unless architecture-level.

**Standards:** Correctness → Readability → Performance → Brevity (never sacrifice the first for the last)

---

## 🎯 ENGINEERING BRIEF

${obj}

**Technology Context:** ${tech}
**Delivery Standard:** Complete, runnable, production-ready — copy-paste and it works

---

## 📋 REQUIREMENTS

- **Functional:** Implement exactly what is specified — don't gold-plate, don't under-deliver
- **Non-functional:** Handle errors gracefully, validate inputs, document edge cases
- **Quality:** Passes peer review — clean names, single-responsibility functions, no side effects without documentation
- **Security:** Sanitize user inputs, no SQL injection vectors, no hardcoded secrets

---

## ⚙️ IMPLEMENTATION PIPELINE

${steps.map((s, i) => `${i+1}. ${s}`).join('\n')}

---

## 📏 CODE QUALITY STANDARDS

${constr.dos.map(d => `- ${d}`).join('\n')}

**Hard stops (never acceptable):**
${constr.donts.map(d => `- ${d}`).join('\n')}

---

## 📊 REQUIRED OUTPUT FORMAT

\`\`\`${ctx.technologies[0] ? ctx.technologies[0].toLowerCase().replace(/\./g, '') : 'language'}
// Complete implementation with inline comments for non-obvious logic
\`\`\`

**Then provide:**
1. **Architecture note** — why this structure was chosen
2. **Usage examples** — realistic inputs showing it working
3. **Test cases** — at minimum: happy path + 2 edge cases + 1 failure
4. **Complexity** — O(?) time, O(?) space
5. **Known limitations** — what this doesn't handle and why

---

## ✅ CODE REVIEW CHECKLIST

- [ ] Zero compilation/runtime errors
- [ ] All inputs validated before use
- [ ] Error handling covers all identified failure modes
- [ ] No deprecated APIs or antipatterns
- [ ] Every function does exactly one thing
- [ ] Test cases would have caught the specified edge cases`;
  }

  // ─── RESEARCH MODE ──────────────────────────────────────────────────────

  function buildResearchPrompt(input, ctx) {
    const obj   = buildObjective(input, ctx);
    const ctxSec= buildContextSection(input, ctx);
    const steps = buildExecutionSteps(ctx);

    return `## 🔬 ROLE

You are a **Research Analyst and Strategic Intelligence Expert**. You turn scattered information into clear, decision-ready insights. Every conclusion is evidence-backed. Every claim has a confidence level. You surface what others miss and say what the evidence actually shows — even when it's inconvenient.

---

## 🎯 RESEARCH OBJECTIVE

${obj}

---

## 📋 RESEARCH CONTEXT

${ctxSec}
- **Evidence standard:** Prioritize specific, verifiable facts over vague generalizations
- **Bias protocol:** Present ALL major perspectives before forming conclusions

---

## ⚙️ RESEARCH PIPELINE

${steps.map((s, i) => `${i+1}. ${s}`).join('\n')}

---

## 📐 EVIDENCE STANDARDS

- 🟢 **High confidence** — multiple independent sources, verifiable, consistent
- 🟡 **Medium confidence** — reasonable inference from available evidence, limited sources
- 🔴 **Low confidence** — speculative, single source, or contested

Apply these labels to every key finding.

---

## 📊 REQUIRED OUTPUT FORMAT

1. **Executive Summary** (4–6 sentences: what you found and what to do about it)
2. **Key Findings** — organized by theme, confidence-labeled
3. **Comparison Matrix** — table format where options/perspectives exist
4. **Risk Register** — likelihood × impact matrix for identified risks
5. **Strategic Recommendations** — specific, prioritized, actionable (not "consider exploring")
6. **Knowledge Gaps** — what remains unknown and why it matters

---

## ✅ RESEARCH QUALITY CHECK

- [ ] No unsupported claims presented as established fact
- [ ] All major viewpoints represented
- [ ] Contradictory evidence addressed, not ignored
- [ ] Recommendations are specific and prioritized
- [ ] Confidence levels assigned to all key findings`;
  }

  // ─── EXAM MODE ──────────────────────────────────────────────────────────

  function buildExamPrompt(input, ctx) {
    const examType = ctx.examType || 'Competitive Exam';
    const subjects = ctx.subjects.length ? ctx.subjects.join(', ') : 'the relevant subjects';
    const obj = buildObjective(input, ctx);
    const steps = buildExecutionSteps(ctx);

    return `## 🎓 ROLE

You are a **${examType} Exam Strategist** and **High-Score Optimizer**. Your job is not to teach — it is to maximize marks. You know exactly which 20% of knowledge yields 80% of exam scores. You know examiner psychology, question patterns, and what distinguishes 95-percentile answers from average ones.

**Mission:** Every minute of preparation must translate directly to marks.

---

## 🎯 EXAM PREPARATION OBJECTIVE

${obj}

---

## 📋 EXAM CONTEXT

- **Target Exam:** ${examType}${ctx.examYear ? ` ${ctx.examYear}` : ''}
- **Subjects in Scope:** ${subjects}
- **Preparation Focus:** High-yield, pattern-based, exam-specific content
- **Time Constraint:** Optimize for efficient preparation — depth only where it scores marks
${ctx.weaknesses.length ? `- **Weakness Profile:** ${ctx.weaknesses[0]} — needs structured recovery plan` : ''}

---

## ⚙️ EXAM PREPARATION PIPELINE

${steps.map((s, i) => `${i+1}. ${s}`).join('\n')}

---

## 📊 REQUIRED OUTPUT STRUCTURE

**Section 1 — Priority Map**
★★★ Critical (must know perfectly) | ★★ Important | ★ Useful if time permits

**Section 2 — Core Concepts (Exam-Ready)**
15–20 must-know concepts in precise examiner language — not textbook language

**Section 3 — Quick Facts Sheet**
Dates, numbers, names, formulas, rules — all formatted for rapid memorization

**Section 4 — ${examType} Pattern Analysis**
Question formats used, common traps, how this topic has been tested in recent papers

**Section 5 — Shortcut Techniques**
Fast elimination for MCQs, keyword recognition, calculation shortcuts

**Section 6 — Practice Questions (8–12)**
Mix: Foundation → Intermediate → Advanced (trap-heavy)
Each with: correct answer + why wrong options are wrong + which exam type/year this style appeared

**Section 7 — Mistake Avoidance Guide**
Top 5–7 errors students make + exactly how to avoid each

**Section 8 — 10-Minute Revision Card**
Absolute minimum to score marks on this topic — readable in under 10 minutes on exam morning

**Section 9 — Memory Aids**
Mnemonics, acronyms, vivid associations for difficult facts

---

## ✅ EXAM PREP QUALITY CHECK

- [ ] All facts accurate — zero misleading content
- [ ] Practice questions match actual ${examType} difficulty and format
- [ ] ★★★ content is genuinely high-frequency, not just complex
- [ ] Mnemonics are accurate AND memorable
- [ ] 10-minute revision fits in 10 minutes`;
  }

  // ─── CREATIVE MODE ──────────────────────────────────────────────────────

  function buildCreativePrompt(input, ctx) {
    const obj = buildObjective(input, ctx);
    const ctxSec = buildContextSection(input, ctx);

    return `## ✍️ ROLE

You are a **Professional Creative Writer and Content Strategist** who produces work that resonates, persuades, and achieves its purpose. You don't just write beautifully — you write strategically. Every creative decision serves the audience and goal.

**Creative Standard:** The piece should feel inevitable — every word earns its place, every structural choice serves the intent.

---

## 🎯 CREATIVE BRIEF

${obj}

---

## 📋 CONTEXT & CONSTRAINTS

${ctxSec}
- **Tone:** Match the brief — don't impose a default voice
- **Length:** Calibrated to purpose and platform, not arbitrary
- **Originality:** Fresh perspective, not recycled tropes

---

## ⚙️ CREATIVE PROCESS

1. **Audience Analysis** — Who reads this? What do they care about? What will make them stop scrolling/continue reading?
2. **Intent Clarity** — What is this piece trying to DO? Inform? Persuade? Entertain? Move emotionally? All four?
3. **Structural Design** — How should this be organized? What creates the right pacing and impact?
4. **Hook Crafting** — The opening must capture immediately. No slow warming up.
5. **Core Content Development** — Build the main body. Every paragraph must earn the reader's continued attention.
6. **Tone Calibration** — Voice consistency throughout. No tonal whiplash.
7. **Closing Impact** — How does this end? The last impression is as important as the first.
8. **Edit Pass** — Remove every word that doesn't add value. Tighten. Sharpen.

---

## 📐 CREATIVE QUALITY STANDARDS

- Every sentence should be interesting enough to re-read
- No clichés unless used intentionally for effect
- The hook should make someone want to read the next line
- The ending should feel earned, not abrupt
- Voice is consistent — reads like one author's voice

---

## 📊 OUTPUT FORMAT

- **The complete, final piece** (ready to use, not a draft)
- **Brief craft notes** (2–3 sentences on the key creative choices made)
- **1 variation** if a different tone/angle would serve the brief equally well

---

## ✅ CREATIVE QUALITY CHECK

- [ ] Hook is genuinely compelling (not just informative)
- [ ] Tone is consistent and appropriate for the target audience
- [ ] No filler sentences — every line advances purpose
- [ ] Ending provides closure and/or impact
- [ ] Piece achieves its stated intent`;
  }

  // ─── RE-OPTIMIZE MODE ───────────────────────────────────────────────────

  function buildReOptimizePrompt(input, ctx) {
    // When re-optimizing an already-structured prompt, do a refinement pass
    return `## 🔁 ADVANCED PROMPT REFINEMENT

You are receiving an already-structured AI prompt for refinement. Your task is not to rebuild it from scratch but to **elevate it to absolute perfection**:

---

**PROMPT TO REFINE:**
${input}

---

## REFINEMENT OBJECTIVES

Analyze the prompt above and improve it across all dimensions:

1. **Role Precision** — Is the role specific enough? Add credentials, domain expertise, or operational context that would improve response quality
2. **Objective Completeness** — Is every success criterion explicit? Add any implied requirements that are missing
3. **Context Enrichment** — What contextual information is assumed but not stated? Make it explicit
4. **Execution Step Specificity** — Are the steps vague? Make each one more concrete and actionable
5. **Constraint Sharpness** — Add any missing constraints; sharpen vague constraints to specific rules
6. **Output Format Clarity** — Is the expected output format completely unambiguous? Specify further
7. **Validation Rigor** — Strengthen the quality checklist with domain-specific criteria
8. **Missing Dimensions** — What important angle does the current prompt NOT address?

---

## OUTPUT

Deliver the **fully refined, perfected version** of the prompt.
Every section should be measurably better than the input version.
Do not just paraphrase — genuinely improve every element.`;
  }

  // ══════════════════════════════════════════════════════════════════════════
  // SCORING
  // ══════════════════════════════════════════════════════════════════════════

  function scoreRawPrompt(text) {
    if (!text || !text.trim()) return 0;
    let score = 0;
    const w = text.trim().split(/\s+/).length;
    if (w > 5)   score += 8;
    if (w > 15)  score += 7;
    if (w > 35)  score += 7;
    if (/i am|i'm|as a/i.test(text))   score += 5;
    if (/\bexam|student|develop|research/i.test(text)) score += 5;
    if (/\bweak|issue|problem|need/i.test(text)) score += 5;
    if (/top \d|list|compare|best/i.test(text)) score += 5;
    if (/##|\*\*|---/.test(text)) score += 25; // already structured
    return Math.min(score, 82);
  }

  function getScoreStages(rawInput) {
    const raw = scoreRawPrompt(rawInput);
    const start = Math.max(2, Math.min(4, Math.floor(raw / 20)));
    return [
      { label: `Analyzing context: ${start}/10`,   delay: 400 },
      { label: `Building structure: ${start+2}/10`, delay: 450 },
      { label: `Enhancing depth: ${start+4}/10`,    delay: 380 },
      { label: `Final refinement: 9/10`,            delay: 300 },
      { label: '✦ 10/10',                          delay: 200 },
    ];
  }

  // ══════════════════════════════════════════════════════════════════════════
  // WORD COUNT GUARD
  // ══════════════════════════════════════════════════════════════════════════

  function ensureWordCount(text, minWords) {
    const count = text.trim().split(/\s+/).length;
    if (count >= minWords) return text;
    return text + `\n\n---\n\n**Note:** Respond with maximum completeness. Cover every dimension of this request. Zero sections should be abbreviated or omitted.`;
  }

  // ══════════════════════════════════════════════════════════════════════════
  // PUBLIC API
  // ══════════════════════════════════════════════════════════════════════════

  return {

    optimize(rawInput, settings) {
      settings = settings || {};
      if (!rawInput || !rawInput.trim()) {
        return { error: 'No input provided. Please type a prompt first.', optimized: null };
      }

      const input     = rawInput.trim();
      const mode      = settings.mode  || 'advanced';
      const inputWords = input.split(/\s+/).length;
      const targetMin  = Math.max(150, inputWords * 7); // at least 7x input

      // Deep context extraction
      const ctx = extractFullContext(input);

      // Re-optimize path: input is already a structured prompt
      if (ctx.isAlreadyOptimized && mode !== 'simple') {
        const refined = buildReOptimizePrompt(input, ctx);
        return {
          optimized:      refined,
          intent:         ctx.action,
          domain:         ctx.domain,
          wordCount:      refined.split(/\s+/).length,
          inputWordCount: inputWords,
          multiplier:     Math.round(refined.split(/\s+/).length / Math.max(1, inputWords)),
          isRefinement:   true,
        };
      }

      let optimized;
      switch (mode) {
        case 'simple':   optimized = buildSimplePrompt(input, ctx);    break;
        case 'basic':    optimized = buildBasicPrompt(input, ctx);     break;
        case 'research': optimized = buildResearchPrompt(input, ctx);  break;
        case 'exam':     optimized = buildExamPrompt(input, ctx);      break;
        case 'coding':   optimized = buildCodePrompt(input, ctx);      break;
        case 'creative': optimized = buildCreativePrompt(input, ctx);  break;
        case 'advanced':
        default:         optimized = buildAdvancedPrompt(input, ctx);  break;
      }

      optimized = ensureWordCount(optimized, targetMin);

      // Non-English note
      const nonAscii = (input.match(/[^\x00-\x7F]/g) || []).length / input.length;
      if (nonAscii > 0.25 || /[\u0900-\u097F\u0600-\u06FF\u4E00-\u9FFF]/.test(input)) {
        optimized += '\n\n---\n*Respond in the same language as this prompt.*';
      }

      return {
        optimized,
        intent:         ctx.action,
        domain:         ctx.domain,
        wordCount:      optimized.split(/\s+/).length,
        inputWordCount: inputWords,
        multiplier:     Math.round(optimized.split(/\s+/).length / Math.max(1, inputWords)),
        examType:       ctx.examType,
        subjects:       ctx.subjects,
      };
    },

    scorePrompt:   scoreRawPrompt,
    getScoreStages,
    getModes() {
      return [
        { key: 'simple',   label: 'Simple' },
        { key: 'advanced', label: 'Advanced' },
        { key: 'basic',    label: 'Basic' },
        { key: 'coding',   label: 'Code' },
        { key: 'research', label: 'Research' },
        { key: 'exam',     label: 'Exam' },
        { key: 'creative', label: 'Creative' },
      ];
    },
  };

})();
