// PromptForge Service Worker — MV3 Background Script
// Handles messaging, settings sync, and tab coordination

const DEFAULT_SETTINGS = {
  mode: 'advanced',
  model: 'auto',
  minLength: 50,
  autoDetect: true,
  widgetPosition: { x: null, y: null },
  theme: 'dark',
  apiKey: '',
  useAI: false,
  style: 'professional',
  depth: 'intermediate'
};

// Initialize storage with defaults on install
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    await chrome.storage.sync.set({ settings: DEFAULT_SETTINGS });
    console.log('[PromptForge] Extension installed. Defaults applied.');
  }

  if (details.reason === 'update') {
    const { settings } = await chrome.storage.sync.get('settings');
    const merged = { ...DEFAULT_SETTINGS, ...settings };
    await chrome.storage.sync.set({ settings: merged });
    console.log('[PromptForge] Extension updated. Settings merged.');
  }
});

// Message router
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case 'GET_SETTINGS':
      handleGetSettings(sendResponse);
      return true; // keep channel open for async

    case 'SAVE_SETTINGS':
      handleSaveSettings(message.payload, sendResponse);
      return true;

    case 'OPTIMIZE_VIA_API':
      handleAPIOptimize(message.payload, sendResponse);
      return true;

    case 'GET_STATS':
      handleGetStats(sendResponse);
      return true;

    case 'INCREMENT_STAT':
      handleIncrementStat(message.payload);
      return false;

    default:
      sendResponse({ error: 'Unknown message type' });
      return false;
  }
});

async function handleGetSettings(sendResponse) {
  try {
    const { settings } = await chrome.storage.sync.get('settings');
    sendResponse({ success: true, data: settings || DEFAULT_SETTINGS });
  } catch (e) {
    sendResponse({ success: false, error: e.message });
  }
}

async function handleSaveSettings(payload, sendResponse) {
  try {
    const { settings } = await chrome.storage.sync.get('settings');
    const updated = { ...settings, ...payload };
    await chrome.storage.sync.set({ settings: updated });
    sendResponse({ success: true });
  } catch (e) {
    sendResponse({ success: false, error: e.message });
  }
}

async function handleAPIOptimize(payload, sendResponse) {
  const { settings } = await chrome.storage.sync.get('settings');
  if (!settings?.apiKey) {
    sendResponse({ success: false, error: 'No API key configured.' });
    return;
  }

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${settings.apiKey}`
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          { role: 'system', content: payload.systemPrompt },
          { role: 'user', content: payload.userPrompt }
        ],
        max_tokens: 1500,
        temperature: 0.7
      })
    });

    const data = await response.json();
    if (data.error) throw new Error(data.error.message);
    sendResponse({ success: true, result: data.choices[0].message.content });
  } catch (e) {
    sendResponse({ success: false, error: e.message });
  }
}

async function handleGetStats(sendResponse) {
  try {
    const { stats } = await chrome.storage.local.get('stats');
    sendResponse({ success: true, data: stats || { optimized: 0, replaced: 0, copied: 0 } });
  } catch (e) {
    sendResponse({ success: false, error: e.message });
  }
}

async function handleIncrementStat(payload) {
  const { stats } = await chrome.storage.local.get('stats');
  const current = stats || { optimized: 0, replaced: 0, copied: 0 };
  current[payload.key] = (current[payload.key] || 0) + 1;
  await chrome.storage.local.set({ stats: current });
}
