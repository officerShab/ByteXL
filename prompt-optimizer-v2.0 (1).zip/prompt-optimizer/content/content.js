// PromptForge Content Script — Main Orchestrator v1.1
// Entry point: platform detection, DOM monitoring, widget, permission gating

(function () {
  'use strict';

  if (window.__promptForgeInitialized) return;
  window.__promptForgeInitialized = true;

  let _widgetInitialized = false;

  // ── Known AI Sites (auto-activate without asking) ──────────────────────
  const KNOWN_AI_DOMAINS = [
    'chatgpt.com', 'chat.openai.com', 'claude.ai', 'gemini.google.com',
    'bard.google.com', 'poe.com', 'perplexity.ai', 'you.com',
    'mistral.ai', 'chat.mistral.ai', 'copilot.microsoft.com',
    'character.ai', 'pi.ai', 'huggingface.co', 'phind.com',
    'cohere.com', 'chat.cohere.com', 'grok.x.ai', 'groq.com',
    'together.ai', 'openrouter.ai', 'chat.deepseek.com', 'kimi.moonshot.cn'
  ];

  function isKnownAiSite() {
    const host = window.location.hostname;
    return KNOWN_AI_DOMAINS.some(d => host.includes(d));
  }

  // ── Safe wrapper ───────────────────────────────────────────────────────
  function safe(fn) {
    try { return fn(); } catch (e) { console.warn('[PromptForge] Safe error:', e); }
  }

  // ── Namespace readiness poller ─────────────────────────────────────────
  function waitForNamespace(maxWait) {
    maxWait = maxWait || 8000;
    return new Promise(function (resolve, reject) {
      var start = Date.now();
      function check() {
        var pf = window.PromptForge;
        if (pf &&
            typeof pf.detectPlatform === 'function' &&
            pf.DOMDetector && typeof pf.DOMDetector.init === 'function' &&
            pf.Widget && typeof pf.Widget.init === 'function' &&
            pf.Engine && typeof pf.Engine.optimize === 'function') {
          resolve(); return;
        }
        if (Date.now() - start > maxWait) {
          var missing = [];
          if (!pf) { missing.push('PromptForge'); }
          else {
            if (!pf.detectPlatform) missing.push('detectPlatform');
            if (!pf.DOMDetector)   missing.push('DOMDetector');
            if (!pf.Widget)        missing.push('Widget');
            if (!pf.Engine)        missing.push('Engine');
          }
          reject(new Error('Timeout waiting for: ' + missing.join(', ')));
          return;
        }
        setTimeout(check, 60);
      }
      check();
    });
  }

  // ── Permission toast for non-AI sites ─────────────────────────────────
  function checkSitePermission() {
    if (isKnownAiSite()) return Promise.resolve(true);

    const domain = window.location.hostname;
    const storageKey = 'pf_site_' + domain.replace(/\./g, '_');

    return new Promise(function (resolve) {
      try {
        chrome.storage.local.get(storageKey, function (result) {
          var stored = result[storageKey];
          if (stored === true)  { resolve(true);  return; }
          if (stored === false) { resolve(false); return; }

          // Show toast
          var toast = document.createElement('div');
          toast.id = 'pf-permission-toast';
          toast.innerHTML =
            '<div style="font-weight:700;margin-bottom:5px;font-size:13px;">⚡ PromptForge</div>' +
            '<div style="color:#aaa;margin-bottom:11px;font-size:11.5px;">Enable AI prompt optimizer on<br><strong style="color:#E8E8F0">' + domain + '</strong>?</div>' +
            '<div style="display:flex;gap:8px">' +
              '<button id="pf-perm-yes" style="flex:1;padding:7px 0;background:#6C63FF;border:none;border-radius:7px;color:#fff;cursor:pointer;font-size:12px;font-weight:600">Enable</button>' +
              '<button id="pf-perm-no" style="flex:1;padding:7px 0;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.15);border-radius:7px;color:#ccc;cursor:pointer;font-size:12px">Not now</button>' +
            '</div>';

          var s = toast.style;
          s.cssText = 'position:fixed;bottom:22px;right:22px;z-index:2147483647;' +
            'background:rgba(13,13,26,0.97);border:1px solid rgba(108,99,255,0.35);' +
            'border-radius:13px;padding:15px 16px;max-width:280px;' +
            'font-family:-apple-system,sans-serif;color:#E8E8F0;' +
            'box-shadow:0 8px 32px rgba(0,0,0,0.5);backdrop-filter:blur(14px);' +
            'animation:pfToastIn 0.3s ease;';

          var style = document.createElement('style');
          style.textContent = '@keyframes pfToastIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}';
          document.head.appendChild(style);
          document.body.appendChild(toast);

          function cleanup(val) {
            try { document.body.removeChild(toast); } catch(e){}
            chrome.storage.local.set({ [storageKey]: val });
            resolve(val);
          }

          document.getElementById('pf-perm-yes').onclick = function() { cleanup(true); };
          document.getElementById('pf-perm-no').onclick  = function() { cleanup(false); };
        });
      } catch (e) {
        // If chrome.storage unavailable, just activate
        resolve(true);
      }
    });
  }

  // ── Core initialization ────────────────────────────────────────────────
  async function initialize() {
    // 1. Namespace check
    try {
      await waitForNamespace();
    } catch (e) {
      console.warn('[PromptForge] Aborted —', e.message);
      return;
    }

    // 2. Permission gate
    try {
      const allowed = await checkSitePermission();
      if (!allowed) {
        console.log('[PromptForge] User declined on this site.');
        return;
      }
    } catch (e) { /* allow on error */ }

    // 3. Detect platform
    const platform = safe(() => window.PromptForge.detectPlatform());
    if (!platform || !platform.adapter) {
      console.warn('[PromptForge] Platform detection failed.');
      return;
    }
    console.log('[PromptForge] Platform:', platform.adapter.name, '| Site:', window.location.hostname);

    // 4. DOM Detector
    safe(() => {
      window.PromptForge.DOMDetector.init(platform, function(inputEl) {
        if (!inputEl) return;
        console.log('[PromptForge] Input found:', inputEl.tagName, (inputEl.className || '').slice(0, 40));
        if (!_widgetInitialized) {
          _widgetInitialized = true;
          safe(() => window.PromptForge.Widget.init(platform));
        }
      });
    });

    // 5. SPA navigation
    if (document.body) {
      var _lastHref = window.location.href;
      new MutationObserver(function() {
        var href = window.location.href;
        if (href !== _lastHref) {
          _lastHref = href;
          console.log('[PromptForge] SPA navigation detected, re-scanning...');
          setTimeout(function() {
            safe(() => window.PromptForge.DOMDetector.redetect());
            _widgetInitialized = false;
          }, 900);
        }
      }).observe(document.body, { childList: true, subtree: true });
    }

    // 6. Message bridge
    if (chrome && chrome.runtime && chrome.runtime.onMessage) {
      chrome.runtime.onMessage.addListener(function(message, _sender, sendResponse) {
        switch (message.type) {
          case 'PING':
            sendResponse({ alive: true, platform: platform.adapter.name });
            break;
          case 'GET_INPUT':
            sendResponse({ text: safe(() => window.PromptForge.DOMDetector.readInput()) || '' });
            break;
          case 'OPTIMIZE_AND_REPLACE': {
            var eng = window.PromptForge && window.PromptForge.Engine;
            if (!eng) { sendResponse({ error: 'Engine not ready' }); break; }
            var payload = message.payload || {};
            var res = safe(() => eng.optimize(payload.text, payload.settings));
            if (res && !res.error) safe(() => window.PromptForge.DOMDetector.writeInput(res.optimized));
            sendResponse(res || { error: 'Optimization failed' });
            break;
          }
          default:
            sendResponse({ error: 'Unknown: ' + message.type });
        }
        return false;
      });
    }
  }

  // Bootstrap
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() { setTimeout(initialize, 80); });
  } else {
    setTimeout(initialize, 100);
  }

})();
