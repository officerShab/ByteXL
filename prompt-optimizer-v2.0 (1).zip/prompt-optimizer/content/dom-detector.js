// PromptForge DOM Detector
// Intelligent input field detection with MutationObserver, heuristics, and retry logic

window.PromptForge = window.PromptForge || {};

window.PromptForge.DOMDetector = (function () {

  let _observer = null;
  let _currentInput = null;
  let _onInputFound = null;
  let _platform = null;
  let _retryCount = 0;
  const MAX_RETRIES = 20;
  const RETRY_INTERVAL_MS = 500;

  /**
   * Score an element to determine likelihood it is the primary prompt input.
   * Higher score = more likely.
   */
  function scoreElement(el) {
    let score = 0;
    const tag = el.tagName.toLowerCase();
    const id = (el.id || '').toLowerCase();
    const className = (el.className || '').toLowerCase();
    const placeholder = (el.getAttribute('placeholder') || '').toLowerCase();
    const role = (el.getAttribute('role') || '').toLowerCase();
    const ariaLabel = (el.getAttribute('aria-label') || '').toLowerCase();

    // Tag scoring
    if (tag === 'textarea') score += 30;
    if (el.isContentEditable) score += 25;
    if (tag === 'input' && el.type === 'text') score += 10;

    // Attribute keyword scoring
    const promptKeywords = ['prompt', 'message', 'input', 'chat', 'query', 'ask', 'type', 'compose', 'editor'];
    for (const kw of promptKeywords) {
      if (id.includes(kw)) score += 15;
      if (className.includes(kw)) score += 10;
      if (placeholder.includes(kw)) score += 12;
      if (ariaLabel.includes(kw)) score += 10;
    }

    // Role bonus
    if (role === 'textbox') score += 8;

    // Size heuristics: large textareas are more likely to be prompt areas
    const rect = el.getBoundingClientRect();
    if (rect.width > 200 && rect.height > 30) score += 5;
    if (rect.width > 400) score += 8;

    // Visibility
    if (rect.width === 0 || rect.height === 0) score -= 50;
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') score -= 50;

    return score;
  }

  /**
   * Find the best candidate input element using platform selectors + heuristics
   */
  function findBestInput() {
    const adapter = _platform.adapter;

    // Try primary selector first
    if (adapter.selectors.primary) {
      const primary = document.querySelector(adapter.selectors.primary);
      if (primary && scoreElement(primary) > 0) return primary;
    }

    // Try fallback selectors
    for (const sel of adapter.selectors.fallback) {
      const els = Array.from(document.querySelectorAll(sel));
      if (els.length > 0) {
        const best = els.sort((a, b) => scoreElement(b) - scoreElement(a))[0];
        if (scoreElement(best) > 10) return best;
      }
    }

    // Universal heuristic scan
    const candidates = [
      ...document.querySelectorAll('textarea'),
      ...document.querySelectorAll('[contenteditable="true"]'),
      ...document.querySelectorAll('input[type="text"]')
    ];

    if (candidates.length === 0) return null;

    const scored = candidates
      .map(el => ({ el, score: scoreElement(el) }))
      .filter(x => x.score > 5)
      .sort((a, b) => b.score - a.score);

    return scored.length > 0 ? scored[0].el : null;
  }

  /**
   * Start observing DOM for input field appearance (handles SPAs and lazy-loaded UIs)
   */
  function startObserver() {
    if (_observer) return;

    _observer = new MutationObserver((mutations) => {
      const needsCheck = mutations.some(m =>
        m.type === 'childList' && m.addedNodes.length > 0
      );
      if (!needsCheck) return;

      const input = findBestInput();
      if (input && input !== _currentInput) {
        _currentInput = input;
        if (_onInputFound) _onInputFound(input);
      }
    });

    _observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  /**
   * Retry-loop detection for slow-loading SPAs
   */
  function retryDetect() {
    if (_retryCount >= MAX_RETRIES) {
      console.warn('[PromptForge] Max retries reached, input field not found.');
      return;
    }

    const input = findBestInput();
    if (input) {
      _currentInput = input;
      if (_onInputFound) _onInputFound(input);
      _retryCount = 0;
    } else {
      _retryCount++;
      setTimeout(retryDetect, RETRY_INTERVAL_MS);
    }
  }

  /**
   * Watch for focus events: re-detect when user focuses something new
   */
  function watchFocusEvents() {
    document.addEventListener('focusin', (e) => {
      const el = e.target;
      if (!el) return;
      const s = scoreElement(el);
      if (s > 15 && el !== _currentInput) {
        _currentInput = el;
        if (_onInputFound) _onInputFound(el);
      }
    }, true);
  }

  return {
    /**
     * Initialize detector
     * @param {Object} platform - from PromptForge.detectPlatform()
     * @param {Function} onInputFound - callback(inputElement)
     */
    init(platform, onInputFound) {
      _platform = platform;
      _onInputFound = onInputFound;
      startObserver();
      watchFocusEvents();
      retryDetect();
    },

    /**
     * Read current input value
     */
    readInput() {
      if (!_currentInput) return '';
      return _platform.adapter.read(_currentInput);
    },

    /**
     * Write value to current input using platform-specific injection
     */
    writeInput(text) {
      if (!_currentInput) return false;
      try {
        _platform.adapter.inject(_currentInput, text);
        _currentInput.focus();
        return true;
      } catch (e) {
        console.error('[PromptForge] Injection failed:', e);
        return false;
      }
    },

    /**
     * Get current detected input element
     */
    getInput() {
      return _currentInput;
    },

    /**
     * Force re-detection (useful after navigation)
     */
    redetect() {
      _currentInput = null;
      _retryCount = 0;
      retryDetect();
    },

    /**
     * Clean up observers
     */
    destroy() {
      if (_observer) {
        _observer.disconnect();
        _observer = null;
      }
    }
  };
})();
