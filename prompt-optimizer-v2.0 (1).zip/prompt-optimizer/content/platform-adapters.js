// PromptForge Platform Adapters v1.3
// ChatGPT: execCommand('insertText') is the correct fix — goes through
// browser's native input pipeline → React handles via single onChange
// (no double-reconcile, no page freeze, even with 2000-word prompts)

window.PromptForge = window.PromptForge || {};

window.PromptForge.PLATFORMS = {
  CHATGPT:'chatgpt', CLAUDE:'claude', GEMINI:'gemini',
  POE:'poe', PERPLEXITY:'perplexity', MISTRAL:'mistral', UNKNOWN:'unknown'
};

// ─── ChatGPT Injector ────────────────────────────────────────────────────
// ROOT CAUSE of "page not responding":
//   Old code: nativeSetter.call(el, text) → dispatchEvent(input) → dispatchEvent(change)
//   React fires TWO full reconciliation cycles synchronously on the main thread.
//   For a 1500-word optimized prompt: resize calc + tokenizer + state updates = 3–8s freeze.
//
// THE FIX: execCommand('insertText') on a focused+selected textarea
//   - Goes through the BROWSER's native input pipeline
//   - React's delegated event listener fires ONE onChange (no double-fire)
//   - Browser batches the DOM update — non-blocking even for large text
//   - This is exactly how a user typing/pasting text works: always responsive

function injectToChatGPT(el, text) {
  try {
    el.focus();
    // Select all existing content so our text replaces it
    el.setSelectionRange(0, el.value.length);
    // execCommand routes through browser's native input path — React loves this
    const ok = document.execCommand('insertText', false, text);
    if (ok && el.value === text) {
      // Move cursor to end and ensure send button activates
      try { el.setSelectionRange(text.length, text.length); } catch(e){}
      return; // ✓ success via clean path
    }
  } catch (e) { /* fall through to fallback */ }

  // Fallback: native setter + deferred single event (avoids double-reconcile)
  try {
    const ns = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,'value').set;
    ns.call(el, text);
  } catch (e) { el.value = text; }

  // rAF + setTimeout double-defer: ensures browser commits current frame before
  // React starts reconciling — eliminates the synchronous main-thread block
  requestAnimationFrame(function () {
    setTimeout(function () {
      el.dispatchEvent(new InputEvent('input', {
        bubbles: true, cancelable: true, inputType: 'insertText'
      }));
      el.focus();
      try { el.setSelectionRange(text.length, text.length); } catch(e){}
    }, 0);
  });
}

// ─── Generic Textarea Injector ───────────────────────────────────────────
// For all non-ChatGPT sites. ONE InputEvent only — no 'change' event.
// Most React/Vue/Angular controlled inputs only need 'input' to sync state.
function injectToTextarea(el, text) {
  try {
    const ns = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,'value').set;
    ns.call(el, text);
  } catch (e) { el.value = text; }
  el.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true }));
}

// ─── ContentEditable Injector ────────────────────────────────────────────
// Preserves newlines. Strategies tried in order until one succeeds.
function injectToContentEditable(el, text) {
  el.focus();

  // Strategy 1: execCommand preserves \n naturally in all Chrome CE divs
  try {
    const sel = window.getSelection();
    if (sel) {
      const range = document.createRange();
      range.selectNodeContents(el);
      sel.removeAllRanges();
      sel.addRange(range);
    } else {
      document.execCommand('selectAll', false, null);
    }
    if (document.execCommand('insertText', false, text)) {
      if ((el.textContent || '').trim().length > 0) {
        el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
        return;
      }
    }
  } catch (e) {}

  // Strategy 2: Build <div> per line DOM structure (correct newline handling)
  try {
    el.innerHTML = '';
    text.split('\n').forEach(function (line) {
      const div = document.createElement('div');
      if (line === '') { div.innerHTML = '<br>'; }
      else { div.textContent = line; }
      el.appendChild(div);
    });
    el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
    return;
  } catch (e) {}

  // Strategy 3: textContent fallback (loses newlines but doesn't crash)
  el.textContent = text;
  el.dispatchEvent(new InputEvent('input', { bubbles: true }));
}

// ─── Platform Adapters ───────────────────────────────────────────────────

window.PromptForge.platformAdapters = {

  chatgpt: {
    name: 'ChatGPT',
    domains: ['chatgpt.com', 'chat.openai.com'],
    selectors: {
      primary: '#prompt-textarea',
      fallback: ['div[contenteditable="true"]', 'textarea[data-id]', 'textarea'],
      container: 'form, .input-area'
    },
    inject(el, text) {
      // MUST use ChatGPT-specific injector — generic causes page freeze
      if (el.tagName === 'TEXTAREA') injectToChatGPT(el, text);
      else injectToContentEditable(el, text);
    },
    read: (el) => el.tagName === 'TEXTAREA' ? el.value : (el.innerText || el.textContent || ''),
    modelHint: 'GPT-4o — Structured prompts with explicit format requirements work best'
  },

  claude: {
    name: 'Claude',
    domains: ['claude.ai'],
    selectors: {
      primary: 'div[contenteditable="true"].ProseMirror',
      fallback: ['div[contenteditable="true"]', '.input-area textarea'],
      container: '.chat-input-area'
    },
    inject: (el, text) => injectToContentEditable(el, text),
    read: (el) => el.innerText || el.textContent || '',
    modelHint: 'Claude — Reasoning-focused, excels with explicit chain-of-thought'
  },

  gemini: {
    name: 'Gemini',
    domains: ['gemini.google.com', 'bard.google.com'],
    selectors: {
      primary: 'div.ql-editor[contenteditable="true"]',
      fallback: ['rich-textarea div[contenteditable]', 'div[contenteditable="true"]'],
      container: '.input-area-container'
    },
    inject(el, text) {
      injectToContentEditable(el, text);
      try { el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'End' })); } catch(e){}
    },
    read: (el) => el.innerText || el.textContent || '',
    modelHint: 'Gemini — Concise, factual queries with clear requirements work best'
  },

  poe: {
    name: 'Poe',
    domains: ['poe.com'],
    selectors: {
      primary: 'textarea.GrowingTextArea_textArea__ZWQbP',
      fallback: ['textarea', 'div[contenteditable="true"]'],
      container: '.ChatMessageInputView_inputContainer'
    },
    inject: (el, text) => el.tagName === 'TEXTAREA' ? injectToTextarea(el, text) : injectToContentEditable(el, text),
    read: (el) => el.value || el.textContent || '',
    modelHint: 'Poe — Multi-model platform, balanced structured approach'
  },

  perplexity: {
    name: 'Perplexity',
    domains: ['perplexity.ai'],
    selectors: {
      primary: 'textarea[placeholder]',
      fallback: ['textarea', 'div[contenteditable="true"]'],
      container: '.grow.overflow-hidden'
    },
    inject: (el, text) => el.tagName === 'TEXTAREA' ? injectToTextarea(el, text) : injectToContentEditable(el, text),
    read: (el) => el.value || el.textContent || '',
    modelHint: 'Perplexity — Research-oriented, include source preferences'
  },

  mistral: {
    name: 'Mistral',
    domains: ['mistral.ai', 'chat.mistral.ai'],
    selectors: { primary: 'textarea', fallback: ['div[contenteditable="true"]'], container: 'form' },
    inject: (el, text) => el.tagName === 'TEXTAREA' ? injectToTextarea(el, text) : injectToContentEditable(el, text),
    read: (el) => el.value || el.textContent || '',
    modelHint: 'Mistral — Clean, precise instructions'
  },

  unknown: {
    name: 'AI Assistant',
    domains: [],
    selectors: {
      primary: null,
      fallback: ['textarea', 'div[contenteditable="true"]', 'input[type="text"]'],
      container: 'form, main, [role="main"]'
    },
    inject: (el, text) => {
      if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') injectToTextarea(el, text);
      else injectToContentEditable(el, text);
    },
    read: (el) => el.value || el.innerText || el.textContent || '',
    modelHint: 'Universal — Balanced, compatible prompt structure'
  }
};

window.PromptForge.detectPlatform = function () {
  const host = window.location.hostname;
  for (const [key, adapter] of Object.entries(window.PromptForge.platformAdapters)) {
    if (adapter.domains.some(d => host.includes(d))) return { key, adapter };
  }
  return { key: 'unknown', adapter: window.PromptForge.platformAdapters.unknown };
};
