// PromptForge Storage Utility
// Thin wrapper around chrome.storage with in-memory cache and fallback

window.PromptForge = window.PromptForge || {};

window.PromptForge.Storage = (function () {
  let _cache = {};

  function isExtensionContext() {
    return typeof chrome !== 'undefined' && chrome.storage;
  }

  return {
    async get(key) {
      if (_cache[key] !== undefined) return _cache[key];
      if (!isExtensionContext()) return null;

      return new Promise((resolve) => {
        chrome.storage.sync.get(key, (result) => {
          _cache[key] = result[key] ?? null;
          resolve(_cache[key]);
        });
      });
    },

    async set(key, value) {
      _cache[key] = value;
      if (!isExtensionContext()) return;

      return new Promise((resolve) => {
        chrome.storage.sync.set({ [key]: value }, resolve);
      });
    },

    async getSettings() {
      const settings = await this.get('settings');
      return settings || {
        mode: 'advanced',
        model: 'auto',
        minLength: 50,
        theme: 'dark',
        depth: 'intermediate',
        widgetPosition: { x: null, y: null }
      };
    },

    async saveWidgetPosition(x, y) {
      const settings = await this.getSettings();
      settings.widgetPosition = { x, y };
      await this.set('settings', settings);
    },

    async getWidgetPosition() {
      const settings = await this.getSettings();
      return settings.widgetPosition || { x: null, y: null };
    },

    invalidate(key) {
      delete _cache[key];
    },

    clearCache() {
      _cache = {};
    }
  };
})();
